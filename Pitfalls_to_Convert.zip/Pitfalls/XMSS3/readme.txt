Esta pitfall se basa en no comprobar que no se haya excedido el counter máximo antes de realizar una firma. La versión buena lo comprueba y la mala solo lo hace una vez
ya ha firmado, no lo comprueba la primera vez. Realmente la función de Botan lo está comprobando internamente, habría que cambiarla pero no merece la pena. 

Pitfall_XMSS3_c.cpp -> lo comprueba en las líneas 28-35
Pitfall_XMSS3_nc.cpp -> No comprueba nada. 
