#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/core_names.h>
#include <openssl/params.h>
#include <iostream>
#include <iomanip>

static void print_hex(const std::string &label, const unsigned char *buf, size_t len) {
    std::cout << label;
    for (size_t i = 0; i < len; i++)
        std::cout << std::hex << std::setw(2) << std::setfill('0') << (int)buf[i];
    std::cout << std::dec << "\n";
}

int main() {
    // PSK 128 bits, pitfall key establishment avoided :)
    const unsigned char PSK[16] = {
        0x01, 0x02, 0x03, 0x04,
        0x05, 0x06, 0x07, 0x08,
        0x09, 0x10, 0x11, 0x12,
        0x13, 0x14, 0x15, 0x16
    };

    // Derive bytes from the pre shared key
    unsigned char okm[96];
    EVP_KDF *kdf = EVP_KDF_fetch(nullptr, "HKDF", nullptr);
    EVP_KDF_CTX *kctx = EVP_KDF_CTX_new(kdf);
    OSSL_PARAM kdf_params[] = {
        OSSL_PARAM_utf8_string(OSSL_KDF_PARAM_DIGEST, (char*)"SHA384", 0),
        OSSL_PARAM_octet_string(OSSL_KDF_PARAM_KEY, (void*)PSK, sizeof(PSK)),
        OSSL_PARAM_END
    };
    EVP_KDF_derive(kctx, okm, sizeof(okm), kdf_params);
    EVP_KDF_CTX_free(kctx);
    EVP_KDF_free(kdf);

    //Get the curve ready
    EVP_PKEY_CTX *ec_ctx = EVP_PKEY_CTX_new_from_name(nullptr, "EC", nullptr);
    EVP_PKEY *pkey = nullptr;

    OSSL_PARAM params[] = {
        OSSL_PARAM_utf8_string(OSSL_PKEY_PARAM_GROUP_NAME, (char*)"secp384r1", 0),
        OSSL_PARAM_octet_string(OSSL_PKEY_PARAM_PRIV_KEY, okm, 48), // just first 48B
        OSSL_PARAM_END
    };
    EVP_PKEY_fromdata_init(ec_ctx);
    EVP_PKEY_fromdata(ec_ctx, &pkey, EVP_PKEY_KEYPAIR, params);

    // Extract and print pub key
    unsigned char pub[97]; size_t publen = sizeof(pub);
    OSSL_PARAM get_params[] = {
        OSSL_PARAM_construct_octet_string(OSSL_PKEY_PARAM_PUB_KEY, pub, publen),
        OSSL_PARAM_END
    };
    EVP_PKEY_get_params(pkey, get_params);

    print_hex("Public key: ", pub, publen);

    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(ec_ctx);
    return 0;
}
