Esta pitfall se basa en emplear claves pre compartidas para ECDH que no tengan suficiente entropía. Deben tener al menos 125 bits, para ello su longitud 
no puede ser menor a 125 bits. El caso bueno usa una PSK de 128 bits, el malo de 120 bits.  

Pitfall_KeyEstablishment_c.cpp -> líneas 16-32 el secreto precompartido es de 128 bits.  
Pitfall_KeyEstablishment_nc.cpp -> líneas 15-35 deriva la clave a partir de un secreto precompartido de 120 bits, líneas 41-45 está derivando la clave privada. 
