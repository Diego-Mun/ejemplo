#include <botan/hmac_drbg.h>
#include <botan/hex.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>

// Take a random seed from /dev/random, if available 
std::vector<uint8_t> get_seed_from_dev_random(size_t seed_len) {
    std::vector<uint8_t> seed(seed_len);
    std::ifstream rnd("/dev/random", std::ios::in | std::ios::binary);
    if (!rnd)
        throw std::runtime_error("Failed to open /dev/random");
    rnd.read(reinterpret_cast<char*>(seed.data()), seed.size());
    if (rnd.gcount() != static_cast<std::streamsize>(seed.size()))
        throw std::runtime_error("Failed to read enough bytes from /dev/random");
    return seed;
}

//Create or reseed
std::unique_ptr<Botan::HMAC_DRBG> create_drbg(size_t seed_len) {
    std::vector<uint8_t> seed = get_seed_from_dev_random(seed_len);
    std::cout << "\n[+] Reseeded (" << seed_len << " bytes): "
              << Botan::hex_encode(seed) << "\n";

    auto drbg = std::make_unique<Botan::HMAC_DRBG>("SHA-256");
    drbg->initialize_with(seed);
    return drbg;
}

int main() {
    try {
        size_t seed_len = 32; 


        auto drbg = create_drbg(seed_len); //The drbg is initiated here

        //after this time or amout of outputs a reseeding is needed
        const size_t reseed_after_outputs = 5;
        const std::chrono::seconds reseed_after_time(10);

        auto last_reseed_time = std::chrono::steady_clock::now();
        size_t outputs_since_reseed = 0;

        while (true) {
        
            std::vector<uint8_t> random_bytes(16); //Generates 128 random bits
            drbg->randomize(random_bytes.data(), random_bytes.size());
            std::cout << "Random data: " << Botan::hex_encode(random_bytes) << "\n";

            outputs_since_reseed++;

            // cheek reseed conditions
            auto now = std::chrono::steady_clock::now();
            bool time_expired = (now - last_reseed_time > reseed_after_time);
            bool output_limit = (outputs_since_reseed >= reseed_after_outputs);

            if (time_expired || output_limit) {
                std::cout << "\n[*] Reseeding due to "
                          << (time_expired ? "time limit" : "output limit") << "...\n";
                drbg = create_drbg(seed_len);
                last_reseed_time = std::chrono::steady_clock::now();
                outputs_since_reseed = 0;
            }

            // the user chooses to continue or not
            std::cout << "Generate another block? (y/n): ";
            char answer;
            std::cin >> answer;
            if (answer != 'y' && answer != 'Y') break;
        }

        std::cout << "\nExiting. DRBG destroyed safely.\n";
    }
    catch (std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
