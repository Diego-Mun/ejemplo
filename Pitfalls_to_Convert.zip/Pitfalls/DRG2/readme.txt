Esta pitfall se basa en hacer reseeding de un drgb tras cierto tiempo o tras una cierta cantidad de outputs. En la versión buena va preguntando 
si se quieren más outputs y si se pasa un tiempo o cantidad de outputs se hace reseeding. En la mala siempre se hace con la misma semilla. 

Pitfall_DRG2_c.cpp -> líneas 46-64 se comprueba el tiempo y la cantidad de outptus, si se sobrepasa se hace reseeding
Pitfall_DRG2_nc.cpp -> líneas 37-49 se siguen generando datos aleatorios sin hacer nunca resseding. 
