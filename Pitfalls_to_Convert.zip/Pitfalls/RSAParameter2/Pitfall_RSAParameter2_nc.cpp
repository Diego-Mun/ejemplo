#include <openssl/bn.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <iostream>
#include <memory>
#include <chrono>

static void openssl_err(const char* where) {
    std::cerr << where << " failed.\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

struct BNDeleter { void operator()(BIGNUM* bn) const { BN_free(bn); } };
using BN_ptr = std::unique_ptr<BIGNUM, BNDeleter>;

int main() {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();

    const int nbits = 2048;
    const unsigned long e_ulong = 65537;
    const int p_bits = nbits / 2;
    const int q_bits = nbits - p_bits;

    BN_CTX* ctx = BN_CTX_new();
    if(!ctx) openssl_err("BN_CTX_new");

    auto start = std::chrono::high_resolution_clock::now();

    BN_ptr e(BN_new());
    BN_set_word(e.get(), e_ulong);

    BN_ptr p(BN_new()), q(BN_new());
    BN_generate_prime_ex(p.get(), p_bits, 0, nullptr, nullptr, nullptr);
    BN_generate_prime_ex(q.get(), q_bits, 0, nullptr, nullptr, nullptr);

    BN_ptr n(BN_new());
    BN_mul(n.get(), p.get(), q.get(), ctx);

    BN_ptr phi(BN_new()), p1(BN_dup(p.get())), q1(BN_dup(q.get()));
    BN_sub_word(p1.get(), 1);
    BN_sub_word(q1.get(), 1);
    BN_mul(phi.get(), p1.get(), q1.get(), ctx);

    BN_ptr d(BN_mod_inverse(nullptr, e.get(), phi.get(), ctx));

    auto end = std::chrono::high_resolution_clock::now();
    double secs = std::chrono::duration<double>(end - start).count();

    int dp = BN_num_bits(p.get());
    int dq = BN_num_bits(q.get());
    int dd = BN_num_bits(d.get());
    std::cout << "p bits: " << dp << ", q bits: " << dq << ", d bits: " << dd << "\n";
    std::cout << "Key generation time: " << secs << " s\n";

    BN_CTX_free(ctx);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
