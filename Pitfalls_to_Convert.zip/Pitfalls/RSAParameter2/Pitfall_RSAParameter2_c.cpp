#include <openssl/bn.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <iostream>
#include <vector>
#include <cstring>
#include <memory>
#include <chrono>

static void openssl_err(const char* where) {
    std::cerr << where << " failed.\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

struct BNDeleter { void operator()(BIGNUM* bn) const { BN_free(bn); } };
struct RSADeleter { void operator()(RSA* r) const { RSA_free(r); } };
struct EVPKeyDel { void operator()(EVP_PKEY* p) const { EVP_PKEY_free(p); } };
struct CtxDel { void operator()(EVP_PKEY_CTX* c) const { EVP_PKEY_CTX_free(c); } };
using BN_ptr = std::unique_ptr<BIGNUM, BNDeleter>;
using RSA_ptr = std::unique_ptr<RSA, RSADeleter>;
using PKEY_ptr = std::unique_ptr<EVP_PKEY, EVPKeyDel>;
using CTX_ptr = std::unique_ptr<EVP_PKEY_CTX, CtxDel>;

int main() {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();

    const int nbits = 2048;
    const unsigned long e_ulong = 65537;

    BN_ptr e(BN_new());
    if(!e || BN_set_word(e.get(), e_ulong) != 1) openssl_err("BN_set_word(e)");

    const int p_bits = nbits / 2;
    const int q_bits = nbits - p_bits;

    BN_CTX* ctx = BN_CTX_new();
    if(!ctx) openssl_err("BN_CTX_new");

    auto start = std::chrono::high_resolution_clock::now();

    BN_ptr p(BN_new()), q(BN_new()), n, phi, d;
    if(!p || !q) openssl_err("BN_new");

    for (;;) {
        if(BN_generate_prime_ex(p.get(), p_bits, 0, nullptr, nullptr, nullptr) != 1)
            openssl_err("BN_generate_prime_ex(p)");
        if(BN_generate_prime_ex(q.get(), q_bits, 0, nullptr, nullptr, nullptr) != 1)
            openssl_err("BN_generate_prime_ex(q)");

        n.reset(BN_new());
        if(BN_mul(n.get(), p.get(), q.get(), ctx) != 1) openssl_err("BN_mul(n)");

        BN_ptr p1(BN_dup(p.get())), q1(BN_dup(q.get()));
        if(BN_sub_word(p1.get(), 1) != 1 || BN_sub_word(q1.get(), 1) != 1)
            openssl_err("BN_sub_word(p1/q1)");
        phi.reset(BN_new());
        if(BN_mul(phi.get(), p1.get(), q1.get(), ctx) != 1)
            openssl_err("BN_mul(phi)");

        d.reset(BN_mod_inverse(nullptr, e.get(), phi.get(), ctx));
        if(!d) continue; // try again if inverse fails
            //Pitfall RSAParameter 2 checks d
        // check d > 2^(n/2)
        BN_ptr threshold(BN_new());
        if(!threshold) openssl_err("BN_new(threshold)");
        if(BN_one(threshold.get()) != 1) openssl_err("BN_one");
        if(BN_lshift(threshold.get(), threshold.get(), nbits/2) != 1)
            openssl_err("BN_lshift");

        if(BN_cmp(d.get(), threshold.get()) > 0) {
            std::cout << "Found valid d > 2^(n/2)\n";
            break;
        }
        // regenerate primes if d is too small
    }

    auto end = std::chrono::high_resolution_clock::now();
    double secs = std::chrono::duration<double>(end - start).count();
    std::cout << "Key generation time: " << secs << " s\n";

    int dp = BN_num_bits(p.get());
    int dq = BN_num_bits(q.get());
    int dd = BN_num_bits(d.get());
    std::cout << "p bits: " << dp << ", q bits: " << dq << ", d bits: " << dd << "\n";

    BN_CTX_free(ctx);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
