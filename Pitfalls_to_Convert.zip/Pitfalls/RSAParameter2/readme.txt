Esta pitfall se basa en no comprobar si d > 2^(n/100)

Pitfall_RSAParameter2_c.cpp-> 66-78 Se comprueba la cota en este fragmento
Pitfall_RSAParameter2_nc.cpp -> no lo comprueba en ninguna línea. 