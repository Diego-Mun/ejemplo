Esta pitfall se basa en no comprobar que los primos p y q tengan tamaño parecido. La mala no lo comprueba la buena sí. 


Pitfall_RSAParameter1_c.cpp -> 69-80 controles de seguridad
Pitfall_RSAParameter1_nc.cpp -> no se comprueba nada