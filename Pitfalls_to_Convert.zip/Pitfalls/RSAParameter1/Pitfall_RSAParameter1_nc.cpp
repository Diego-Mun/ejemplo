#include <openssl/bn.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#include <iostream>
#include <vector>
#include <cstring>
#include <memory>

static void openssl_err(const char* where) {
    std::cerr << where << " failed.\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

struct BNDeleter { void operator()(BIGNUM* bn) const { BN_free(bn); } };
struct RSADeleter { void operator()(RSA* r) const { RSA_free(r); } };
struct EVPKeyDel { void operator()(EVP_PKEY* p) const { EVP_PKEY_free(p); } };
struct CtxDel { void operator()(EVP_PKEY_CTX* c) const { EVP_PKEY_CTX_free(c); } };
using BN_ptr = std::unique_ptr<BIGNUM, BNDeleter>;
using RSA_ptr = std::unique_ptr<RSA, RSADeleter>;
using PKEY_ptr = std::unique_ptr<EVP_PKEY, EVPKeyDel>;
using CTX_ptr = std::unique_ptr<EVP_PKEY_CTX, CtxDel>;

// Helper: duplicate BIGNUM
BN_ptr dup_bn(const BIGNUM* x) {
    BN_ptr r(BN_dup(x));
    if(!r) openssl_err("BN_dup");
    return r;
}

int main() {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();

    const int nbits = 2048;
    const unsigned long e_ulong = 65537;

    // Create exponent e
    BN_ptr e(BN_new());
    if(!e || BN_set_word(e.get(), e_ulong) != 1) openssl_err("BN_set_word(e)");

    const int p_bits = nbits / 2;
    const int q_bits = nbits - p_bits; // may differ by 1

    BN_CTX* ctx = BN_CTX_new();
    if(!ctx) openssl_err("BN_CTX_new");

    // --- Insecure prime generation (no checks) ---
    BN_ptr p(BN_new()), q(BN_new());
    if(!p || !q) openssl_err("BN_new");

    if(BN_generate_prime_ex(p.get(), p_bits, 0, nullptr, nullptr, nullptr) != 1)
        openssl_err("BN_generate_prime_ex(p)");
    if(BN_generate_prime_ex(q.get(), q_bits, 0, nullptr, nullptr, nullptr) != 1)
        openssl_err("BN_generate_prime_ex(q)");

    int bp = BN_num_bits(p.get());
    int bq = BN_num_bits(q.get());
    std::cout << "Generated p bits = " << bp << ", q bits = " << bq << "\n";

    // --- Build RSA key manually ---
    BN_ptr n(BN_new());
    if(!n || BN_mul(n.get(), p.get(), q.get(), ctx) != 1) openssl_err("BN_mul(n)");

    BN_ptr p1(BN_dup(p.get()));
    BN_ptr q1(BN_dup(q.get()));
    if(BN_sub_word(p1.get(), 1) != 1) openssl_err("BN_sub_word(p1)");
    if(BN_sub_word(q1.get(), 1) != 1) openssl_err("BN_sub_word(q1)");

    BN_ptr phi(BN_new());
    if(!phi || BN_mul(phi.get(), p1.get(), q1.get(), ctx) != 1) openssl_err("BN_mul(phi)");

    BN_ptr d(BN_mod_inverse(nullptr, e.get(), phi.get(), ctx));
    if(!d) openssl_err("BN_mod_inverse(d)");

    // CRT params
    BN_ptr dmp1(BN_new()), dmq1(BN_new()), iqmp(BN_new());
    if(!dmp1 || !dmq1 || !iqmp) openssl_err("BN_new CRT");
    if(BN_mod(dmp1.get(), d.get(), p1.get(), ctx) != 1) openssl_err("BN_mod(dmp1)");
    if(BN_mod(dmq1.get(), d.get(), q1.get(), ctx) != 1) openssl_err("BN_mod(dmq1)");
    if(BN_mod_inverse(iqmp.get(), q.get(), p.get(), ctx) == nullptr)
        openssl_err("BN_mod_inverse(iqmp)");

    // Build RSA and EVP_PKEY
    RSA_ptr rsa(RSA_new());
    if(!rsa) openssl_err("RSA_new");
    if(RSA_set0_key(rsa.get(), BN_dup(n.get()), BN_dup(e.get()), BN_dup(d.get())) != 1)
        openssl_err("RSA_set0_key");
    if(RSA_set0_factors(rsa.get(), BN_dup(p.get()), BN_dup(q.get())) != 1)
        openssl_err("RSA_set0_factors");
    if(RSA_set0_crt_params(rsa.get(), BN_dup(dmp1.get()), BN_dup(dmq1.get()), BN_dup(iqmp.get())) != 1)
        openssl_err("RSA_set0_crt_params");

    PKEY_ptr pkey(EVP_PKEY_new());
    if(!pkey || EVP_PKEY_assign_RSA(pkey.get(), rsa.release()) != 1)
        openssl_err("EVP_PKEY_assign_RSA");

    // Save PEM keys
    {
        FILE* fpub = fopen("rsa_public_insecure.pem", "w");
        FILE* fpriv = fopen("rsa_private_insecure.pem", "w");
        if(!fpub || !fpriv) { perror("fopen"); return EXIT_FAILURE; }
        PEM_write_PUBKEY(fpub, pkey.get());
        PEM_write_PrivateKey(fpriv, pkey.get(), nullptr, nullptr, 0, nullptr, nullptr);
        fclose(fpub); fclose(fpriv);
        std::cout << "Saved rsa_public_insecure.pem and rsa_private_insecure.pem\n";
    }

    // --- RSA-OAEP (SHA-256) encryption/decryption demo ---
    const char* msg = "Testing insecure primes RSA-OAEP with SHA-256";
    size_t msg_len = std::strlen(msg);

    CTX_ptr enc_ctx(EVP_PKEY_CTX_new(pkey.get(), nullptr));
    if(!enc_ctx) openssl_err("EVP_PKEY_CTX_new(enc)");
    if(EVP_PKEY_encrypt_init(enc_ctx.get()) != 1) openssl_err("EVP_PKEY_encrypt_init");
    if(EVP_PKEY_CTX_set_rsa_padding(enc_ctx.get(), RSA_PKCS1_OAEP_PADDING) != 1)
        openssl_err("set_rsa_padding");
    if(EVP_PKEY_CTX_set_rsa_oaep_md(enc_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_oaep_md");
    if(EVP_PKEY_CTX_set_rsa_mgf1_md(enc_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_mgf1_md");

    size_t ct_len = 0;
    EVP_PKEY_encrypt(enc_ctx.get(), nullptr, &ct_len,
                     reinterpret_cast<const unsigned char*>(msg), msg_len);
    std::vector<unsigned char> ct(ct_len);
    if(EVP_PKEY_encrypt(enc_ctx.get(), ct.data(), &ct_len,
                        reinterpret_cast<const unsigned char*>(msg), msg_len) != 1)
        openssl_err("EVP_PKEY_encrypt");

    std::cout << "Encrypted message (" << ct_len << " bytes)\n";

    // Decrypt
    CTX_ptr dec_ctx(EVP_PKEY_CTX_new(pkey.get(), nullptr));
    if(!dec_ctx) openssl_err("EVP_PKEY_CTX_new(dec)");
    if(EVP_PKEY_decrypt_init(dec_ctx.get()) != 1) openssl_err("EVP_PKEY_decrypt_init");
    if(EVP_PKEY_CTX_set_rsa_padding(dec_ctx.get(), RSA_PKCS1_OAEP_PADDING) != 1)
        openssl_err("set_rsa_padding(dec)");
    if(EVP_PKEY_CTX_set_rsa_oaep_md(dec_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_oaep_md(dec)");
    if(EVP_PKEY_CTX_set_rsa_mgf1_md(dec_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_mgf1_md(dec)");

    size_t pt_len = 0;
    EVP_PKEY_decrypt(dec_ctx.get(), nullptr, &pt_len, ct.data(), ct_len);
    std::vector<unsigned char> pt(pt_len);
    if(EVP_PKEY_decrypt(dec_ctx.get(), pt.data(), &pt_len, ct.data(), ct_len) != 1)
        openssl_err("EVP_PKEY_decrypt");

    std::cout << "Decrypted message: "
              << std::string(reinterpret_cast<char*>(pt.data()), pt_len) << "\n";

    BN_CTX_free(ctx);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
