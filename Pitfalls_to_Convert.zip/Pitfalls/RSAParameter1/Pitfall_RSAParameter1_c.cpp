#include <openssl/bn.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#include <iostream>
#include <vector>
#include <cstring>
#include <memory>

static void openssl_err(const char* where) {
    std::cerr << where << " failed.\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

struct BNDeleter { void operator()(BIGNUM* bn) const { BN_free(bn); } };
struct RSADeleter { void operator()(RSA* r) const { RSA_free(r); } };
struct EVPKeyDel { void operator()(EVP_PKEY* p) const { EVP_PKEY_free(p); } };
struct CtxDel { void operator()(EVP_PKEY_CTX* c) const { EVP_PKEY_CTX_free(c); } };
using BN_ptr = std::unique_ptr<BIGNUM, BNDeleter>;
using RSA_ptr = std::unique_ptr<RSA, RSADeleter>;
using PKEY_ptr = std::unique_ptr<EVP_PKEY, EVPKeyDel>;
using CTX_ptr = std::unique_ptr<EVP_PKEY_CTX, CtxDel>;

BN_ptr dup_bn(const BIGNUM* x) {
    BN_ptr r(BN_dup(x));
    if(!r) openssl_err("BN_dup");
    return r;
}

// Generates a prime of 'bits' such that gcd(p-1, e)=1
BN_ptr generate_prime_with_e(int bits, const BIGNUM* e) {
    BN_ptr p(BN_new());
    BN_ptr pm1(BN_new());
    BN_CTX* ctx = BN_CTX_new();
    if(!p || !pm1 || !ctx) openssl_err("alloc BN/CTX");

    for(;;) {
        // BN_generate_prime_ex generates a probable prime; intermediate checks are internal as well.
        if(BN_generate_prime_ex(p.get(), bits, 0, nullptr, nullptr, nullptr) != 1)
            openssl_err("BN_generate_prime_ex");
        if(!BN_copy(pm1.get(), p.get())) openssl_err("BN_copy");
        if(BN_sub_word(pm1.get(), 1) != 1) openssl_err("BN_sub_word");
        // Check gcd(p-1, e) == 1
        BN_ptr g(BN_new());
        if(!g) openssl_err("BN_new");
        if(BN_gcd(g.get(), pm1.get(), e, ctx) != 1) openssl_err("BN_gcd");
        if(BN_is_one(g.get())) {
            BN_CTX_free(ctx);
            return p;
        }
        // if not, try another prime
    }
}

int main(int argc, char** argv) {
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();

    const int nbits = 2048;           // modulus size
    const unsigned long e_ulong = 65537;

    // e = 65537
    BN_ptr e(BN_new());
    if(!e || BN_set_word(e.get(), e_ulong) != 1) openssl_err("BN_set_word(e)");

    // Rules for “similar size” and “not too close”
    /*
    Pitfall RSAParameter1 
    */
    const int p_bits = nbits/2;
    const int q_bits = nbits - p_bits; // in case nbits is odd
    const int max_bitlen_diff = 2;     // tolerance for p vs q bit length
    const int min_diff_bits = (nbits/2) - 100; // |p - q| must have at least this many bits (simple heuristic)

    BN_ptr p, q, n, phi, d, p1, q1, dmp1, dmq1, iqmp;
    BN_CTX* ctx = BN_CTX_new();
    if(!ctx) openssl_err("BN_CTX_new");

    // Generate p and q with checks
    for(;;) {
        p = generate_prime_with_e(p_bits, e.get());
        q = generate_prime_with_e(q_bits, e.get());
        if(BN_cmp(p.get(), q.get()) == 0) continue;

        int bp = BN_num_bits(p.get());
        int bq = BN_num_bits(q.get());
        int diff = (bp > bq) ? (bp - bq) : (bq - bp);

        // |p - q|
        BN_ptr diffpq(BN_new());
        if(!diffpq) openssl_err("BN_new");
        if(BN_ucmp(p.get(), q.get()) >= 0) {
            if(BN_copy(diffpq.get(), p.get()) == nullptr) openssl_err("BN_copy");
            if(BN_sub(diffpq.get(), diffpq.get(), q.get()) != 1) openssl_err("BN_sub");
        } else {
            if(BN_copy(diffpq.get(), q.get()) == nullptr) openssl_err("BN_copy");
            if(BN_sub(diffpq.get(), diffpq.get(), p.get()) != 1) openssl_err("BN_sub");
        }
        int diff_bits = BN_num_bits(diffpq.get());

        if(diff <= max_bitlen_diff && diff_bits >= min_diff_bits) {
            std::cout << "p bits = " << bp << ", q bits = " << bq
                      << " (|p-q| bits = " << diff_bits << ")\n";
            break; // accept these p and q
        }
        // if not valid, try again
    }

    // n = p*q
    n.reset(BN_new());
    if(!n || BN_mul(n.get(), p.get(), q.get(), ctx) != 1) openssl_err("BN_mul(n)");

    // phi = (p-1)*(q-1)
    p1.reset(BN_dup(p.get())); if(!p1) openssl_err("BN_dup");
    q1.reset(BN_dup(q.get())); if(!q1) openssl_err("BN_dup");
    if(BN_sub_word(p1.get(), 1) != 1) openssl_err("BN_sub_word(p1)");
    if(BN_sub_word(q1.get(), 1) != 1) openssl_err("BN_sub_word(q1)");
    phi.reset(BN_new());
    if(!phi || BN_mul(phi.get(), p1.get(), q1.get(), ctx) != 1) openssl_err("BN_mul(phi)");

    // d = e^{-1} mod phi
    d.reset(BN_mod_inverse(nullptr, e.get(), phi.get(), ctx));
    if(!d) openssl_err("BN_mod_inverse(d)");

    // CRT parameters
    dmp1.reset(BN_new());
    dmq1.reset(BN_new());
    iqmp.reset(BN_new());
    if(!dmp1 || !dmq1 || !iqmp) openssl_err("BN_new CRT");
    if(BN_mod(dmp1.get(), d.get(), p1.get(), ctx) != 1) openssl_err("BN_mod(dmp1)");
    if(BN_mod(dmq1.get(), d.get(), q1.get(), ctx) != 1) openssl_err("BN_mod(dmq1)");
    if(BN_mod_inverse(iqmp.get(), q.get(), p.get(), ctx) == nullptr) openssl_err("BN_mod_inverse(iqmp)");

    // Build RSA and EVP_PKEY
    RSA_ptr rsa(RSA_new());
    if(!rsa) openssl_err("RSA_new");

    // set0 transfers ownership to rsa (do not free later p,q,n,e,d,dmp1,...)
    if(RSA_set0_key(rsa.get(), BN_dup(n.get()), BN_dup(e.get()), BN_dup(d.get())) != 1)
        openssl_err("RSA_set0_key");
    if(RSA_set0_factors(rsa.get(), BN_dup(p.get()), BN_dup(q.get())) != 1)
        openssl_err("RSA_set0_factors");
    if(RSA_set0_crt_params(rsa.get(), BN_dup(dmp1.get()), BN_dup(dmq1.get()), BN_dup(iqmp.get())) != 1)
        openssl_err("RSA_set0_crt_params");

    PKEY_ptr pkey(EVP_PKEY_new());
    if(!pkey || EVP_PKEY_assign_RSA(pkey.get(), rsa.release()) != 1)
        openssl_err("EVP_PKEY_assign_RSA");

    // Save to PEM
    {
        FILE* fpub = fopen("rsa_public.pem", "w");
        FILE* fpriv = fopen("rsa_private.pem", "w");
        if(!fpub || !fpriv) { perror("fopen"); return EXIT_FAILURE; }
        if(PEM_write_PUBKEY(fpub, pkey.get()) != 1) openssl_err("PEM_write_PUBKEY");
        if(PEM_write_PrivateKey(fpriv, pkey.get(), nullptr, nullptr, 0, nullptr, nullptr) != 1)
            openssl_err("PEM_write_PrivateKey");
        fclose(fpub); fclose(fpriv);
        std::cout << "Saved rsa_public.pem and rsa_private.pem\n";
    }

    // —— Demonstration: encryption/decryption OAEP(SHA-256) ——
    const char* msg = "Secret message: hello RSA-OAEP with SHA-256";
    size_t msg_len = std::strlen(msg);

    // Encrypt with public key
    CTX_ptr enc_ctx(EVP_PKEY_CTX_new(pkey.get(), nullptr));
    if(!enc_ctx) openssl_err("EVP_PKEY_CTX_new(enc)");
    if(EVP_PKEY_encrypt_init(enc_ctx.get()) != 1) openssl_err("EVP_PKEY_encrypt_init");
    if(EVP_PKEY_CTX_set_rsa_padding(enc_ctx.get(), RSA_PKCS1_OAEP_PADDING) != 1)
        openssl_err("set_rsa_padding");
    if(EVP_PKEY_CTX_set_rsa_oaep_md(enc_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_oaep_md");
    if(EVP_PKEY_CTX_set_rsa_mgf1_md(enc_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_mgf1_md");

    size_t ct_len = 0;
    if(EVP_PKEY_encrypt(enc_ctx.get(), nullptr, &ct_len,
                        reinterpret_cast<const unsigned char*>(msg), msg_len) != 1)
        openssl_err("EVP_PKEY_encrypt(size)");
    std::vector<unsigned char> ct(ct_len);
    if(EVP_PKEY_encrypt(enc_ctx.get(), ct.data(), &ct_len,
                        reinterpret_cast<const unsigned char*>(msg), msg_len) != 1)
        openssl_err("EVP_PKEY_encrypt");

    std::cout << "Encryption OK. Ciphertext bytes = " << ct_len << "\n";

    // Decrypt with private key
    CTX_ptr dec_ctx(EVP_PKEY_CTX_new(pkey.get(), nullptr));
    if(!dec_ctx) openssl_err("EVP_PKEY_CTX_new(dec)");
    if(EVP_PKEY_decrypt_init(dec_ctx.get()) != 1) openssl_err("EVP_PKEY_decrypt_init");
    if(EVP_PKEY_CTX_set_rsa_padding(dec_ctx.get(), RSA_PKCS1_OAEP_PADDING) != 1)
        openssl_err("set_rsa_padding(dec)");
    if(EVP_PKEY_CTX_set_rsa_oaep_md(dec_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_oaep_md(dec)");
    if(EVP_PKEY_CTX_set_rsa_mgf1_md(dec_ctx.get(), EVP_sha256()) != 1)
        openssl_err("set_mgf1_md(dec)");

    size_t pt_len = 0;
    if(EVP_PKEY_decrypt(dec_ctx.get(), nullptr, &pt_len, ct.data(), ct_len) != 1)
        openssl_err("EVP_PKEY_decrypt(size)");
    std::vector<unsigned char> pt(pt_len);
    if(EVP_PKEY_decrypt(dec_ctx.get(), pt.data(), &pt_len, ct.data(), ct_len) != 1)
        openssl_err("EVP_PKEY_decrypt");

    std::cout << "Decryption OK. Message: "
              << std::string(reinterpret_cast<char*>(pt.data()), pt_len) << "\n";

    BN_CTX_free(ctx);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
