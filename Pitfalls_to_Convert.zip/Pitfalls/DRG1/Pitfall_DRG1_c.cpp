#include <botan/auto_rng.h>
#include <botan/hmac_drbg.h>
#include <botan/hex.h>
#include <fstream>
#include <iostream>
#include <vector>

int main() {
    try {
        size_t seed_len = 32; //pitfall DRG1 avoided, the lenght is enough


        // --- 1) Read entropy from /dev/random ---
        std::vector<uint8_t> seed(seed_len);
        std::ifstream urandom("/dev/random", std::ios::in | std::ios::binary);
        if (!urandom) {
            throw std::runtime_error("Failed to open /dev/random");
        }
        urandom.read(reinterpret_cast<char*>(seed.data()), seed.size());
        if (urandom.gcount() != static_cast<std::streamsize>(seed.size())) {
            throw std::runtime_error("Failed to read enough bytes from /dev/random");
        }
        urandom.close();

        std::cout << "Seed (" << seed_len << " bytes): "
                  << Botan::hex_encode(seed) << "\n";

        // --- 2) Create an HMAC-DRBG with SHA-256 ---
        std::unique_ptr<Botan::HMAC_DRBG> drbg =
            std::make_unique<Botan::HMAC_DRBG>("SHA-256");

        // --- 3) Initialize with the seed ---
        drbg->initialize_with(seed);

        // --- 4) Generate some random output (example: 32 bytes) ---
        std::vector<uint8_t> output(32);
        drbg->randomize(output.data(), output.size());

        std::cout << "Generated random data: "
                  << Botan::hex_encode(output) << "\n";
    }
    catch (std::exception &e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
