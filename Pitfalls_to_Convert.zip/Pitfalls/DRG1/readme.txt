Esta pitfall se basa en no suministrar suficiente entropía en la semilla de un drbg. Para ello la longitud debe ser de al menos 125 bits. 
La versión buena tiene 128 bits y la mala 124. La propia función de botan capta que no le estás metiendo suficiente entropía al ejecutarlo, pero debería 
pillarlo también el SAST. 

Pitfall_DRG1_c.cpp -> línea 10 se usan 128 bits de seed
Pitfall_DRG1_nc.cpp -> línea 10 se usan 124 bits de seed
