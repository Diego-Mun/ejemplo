Esta pitfall se basa en no comprobar que los puntos recibidos pertenezcan al subgrupo correcto en DH y DSA. Para la implementación recibimos un 
punto de FFDHE-2048 y comprobamos que está en el subgrupo en el que debería. 

Pitfall_FFDLOG2_c.cpp -> 34-70 comprueba que el punto recibido esté en el subgrupo y no sea ni nulo ni 1. 109-116 solo manda el punto si 
se comprueba bien que pertenece al subgrupo
Pitfall_FFDLOG2_nc.cpp -> No comprueba nada, se manda directamente en la línea 67.
