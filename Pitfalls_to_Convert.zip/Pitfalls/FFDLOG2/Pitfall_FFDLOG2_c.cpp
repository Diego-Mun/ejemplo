#include <openssl/bn.h>
#include <openssl/err.h>
#include <iostream>
#include <string>



void compute_diffie_hellman_secret(const BIGNUM* y, const BIGNUM* p, const BIGNUM* g, const BIGNUM* q);

// Print BN as hex
void printBN(const char* label, const BIGNUM* bn) {
    char* hex = BN_bn2hex(bn);
    std::cout << label << ": " << hex << "\n";
    OPENSSL_free(hex);
}

// Return a freshly allocated 2048-bit safe prime p (RFC 3526 group 14) and g=2.
// We also compute q=(p-1)/2 for subgroup checks.
bool load_modp_2048(BIGNUM*& p, BIGNUM*& g, BIGNUM*& q, BN_CTX* ctx) {
    p = BN_get_rfc3526_prime_2048(nullptr); // OpenSSL built-in safe prime
    if (!p) return false;
    g = BN_new();
    if (!g) return false;
    BN_set_word(g, 2);

    // q = (p-1)/2
    q = BN_dup(p);
    if (!q) return false;
    if (!BN_sub_word(q, 1)) return false;
    if (!BN_rshift1(q, q)) return false; // q = (p-1)/2
    return true;
}

// Subgroup validation for a peer element y in Z_p^*:
// 1) 2 <= y <= p-2  (reject 0,1,p-1)
// 2) y^q mod p == 1 (membership in order-q subgroup)
// 3) y != p-1       (explicitly reject order-2 element)
bool dh_check_element_ffdhe_like(const BIGNUM* y, const BIGNUM* p, const BIGNUM* q, BN_CTX* ctx, std::string& why) {
    // Check 1 < y < p-1   (equivalently 2 <= y <= p-2)
    if (BN_is_zero(y) || BN_is_one(y)) {
        why = "y is 0 or 1 (invalid range).";
        return false;
    }
    BIGNUM* pm1 = BN_dup(p);
    BN_sub_word(pm1, 1); // p-1
    if (BN_cmp(y, pm1) >= 0) {
        BN_free(pm1);
        why = "y is >= p-1 (invalid range).";
        return false;
    }

    // Reject y == p-1 (order 2)
    if (BN_cmp(y, pm1) == 0) {
        BN_free(pm1);
        why = "y equals p-1 (order 2 element).";
        return false;
    }
    BN_free(pm1);

    // Subgroup test: y^q mod p == 1
    BIGNUM* t = BN_new();
    if (!BN_mod_exp(t, y, q, p, ctx)) {
        BN_free(t);
        why = "BN_mod_exp failed.";
        return false;
    }
    bool ok = BN_is_one(t);
    BN_free(t);
    if (!ok) {
        why = "y^q mod p != 1 (not in the intended subgroup).";
        return false;
    }
    return true;
}

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: ./dh_subgroup_check <peer_elem_hex>\n"
                  << "Example: ./dh_subgroup_check A1B2C3...\n";
        return 1;
    }

    BN_CTX* ctx = BN_CTX_new();
    if (!ctx) {
        std::cerr << "BN_CTX_new failed\n";
        return 1;
    }

    // Load standard 2048-bit safe-prime group (p,g), compute q=(p-1)/2
    BIGNUM *p=nullptr, *g=nullptr, *q=nullptr;
    if (!load_modp_2048(p, g, q, ctx)) {
        std::cerr << "Failed to load MODP 2048 group.\n";
        BN_CTX_free(ctx);
        return 1;
    }

    // Parse peer element y from hex
    BIGNUM* y = nullptr;
    if (!BN_hex2bn(&y, argv[1])) {
        std::cerr << "Failed to parse hex y.\n";
        BN_free(p); BN_free(g); BN_free(q);
        BN_CTX_free(ctx);
        return 1;
    }

    // Optional: show parameters once
    // printBN("p", p); printBN("g", g); printBN("q", q); printBN("y", y);

    std::string why;
    bool ok = dh_check_element_ffdhe_like(y, p, q, ctx, why);
    if (ok) {
        std::cout << "Subgroup check: OK (y is in the order-q subgroup for this group).\n";
        compute_diffie_hellman_secret(y, p, g, q);
    } else {
        std::cout << "Subgroup check: FAIL — " << why << "\n";
    }

    BN_free(y);
    BN_free(p); BN_free(g); BN_free(q);
    BN_CTX_free(ctx);
    return ok ? 0 : 2;
}
