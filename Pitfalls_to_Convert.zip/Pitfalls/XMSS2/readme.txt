Esta pitfall se basa en utilizar la misma clave y counter para firmar dos mensajes distintos. La versión buena siempre actualiza el índice al firmar, de forma que no 
se puedan firmar dos mensajes con el mismo par clave/indice. La versión vulnerable hace una copia de la clave privada y la usa para firmar dos mensajes distintos, 
no queda muy claro que el sast lo vaya a entender como la misma clave, pero de otra forma habría que modificar la propia función de Botan, y todo ese trabajo
no merece la pena. 

Pitfall_XMSS2_c.cpp -> Lo hace bien, no hay una línea concreta
Pitfall_XMSS2_nc.cpp -> línea 19 copia la clave privada, líneas 39-50 firma con la copia de la clave privada, por lo tanto se ha usado la misma clave/counter para 
2 mensajes distintos. 
