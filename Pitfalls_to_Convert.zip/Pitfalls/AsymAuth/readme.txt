Esta pitfall se basa en utlizar la misma clave para autenticar datos y usuarios. La versión mala utiliza la misma clave para firmar un archivo
y también para firmar un string que se pasa como input por línea de comando, simulando un proceso de autenticación. La parte de la autenticación 
va escrito a modo de challenge response, para simular el proceso de autenticación. 

Pitfall_AsymAuth_c.cpp -> líneas 127 a 139 carga 2 claves distintas, 148-151 firma el archivo y el challenge con claves distintas
Pitfall_AsymAuth_nc.cpp -> Líneas 126-141 utiliza la misma clave para firmar un archivo y para autenticarse mediante un challenge response
