#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>
#include <chrono> 

static void fail(const char *msg)
{
    std::cerr << "[!] " << msg << "\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

static std::vector<unsigned char> read_file(const std::string &path)
{
    std::ifstream f(path, std::ios::binary);
    if (!f)
        fail(("Cannot open file: " + path).c_str());
    return std::vector<unsigned char>((std::istreambuf_iterator<char>(f)),
                                      std::istreambuf_iterator<char>());
}

static void print_hex(const std::string &label, const unsigned char *buf, size_t len)
{
    std::cout << label;
    for (size_t i = 0; i < len; ++i)
        std::cout << std::hex << std::setw(2) << std::setfill('0') << (int)buf[i];
    std::cout << std::dec << "\n";
}

static std::vector<unsigned char> ecdsa_sign(const EVP_PKEY *pkey,
                                             const std::vector<unsigned char> &data)
{
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx)
        fail("EVP_MD_CTX_new failed");

    if (EVP_DigestSignInit(ctx, nullptr, EVP_sha384(), nullptr, const_cast<EVP_PKEY*>(pkey)) != 1)
        fail("EVP_DigestSignInit failed");

    if (EVP_DigestSignUpdate(ctx, data.data(), data.size()) != 1)
        fail("EVP_DigestSignUpdate failed");

    size_t sig_len = 0;
    if (EVP_DigestSignFinal(ctx, nullptr, &sig_len) != 1)
        fail("EVP_DigestSignFinal (size) failed");

    std::vector<unsigned char> signature(sig_len);
    if (EVP_DigestSignFinal(ctx, signature.data(), &sig_len) != 1)
        fail("EVP_DigestSignFinal failed");

    signature.resize(sig_len);
    EVP_MD_CTX_free(ctx);
    return signature;
}

std::vector<unsigned char> sign_challenge(EVP_PKEY *pkey,
                                          const std::vector<unsigned char> &nonce,
                                          std::string &timestamp)
{
    // ---- 1) Generate timestamp (seconds since epoch)
    std::ostringstream ts_stream;
    ts_stream << std::time(nullptr);
    timestamp = ts_stream.str();

    // ---- 2) Concatenate nonce || timestamp ----
    std::vector<unsigned char> message;
    message.reserve(nonce.size() + timestamp.size());
    message.insert(message.end(), nonce.begin(), nonce.end());
    message.insert(message.end(), timestamp.begin(), timestamp.end());

    // ---- 3) Sign using ECDSA (P-384 / SHA-384) ----
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx)
        fail("EVP_MD_CTX_new failed");

    if (EVP_DigestSignInit(ctx, nullptr, EVP_sha384(), nullptr, pkey) != 1)
        fail("EVP_DigestSignInit failed");

    if (EVP_DigestSignUpdate(ctx, message.data(), message.size()) != 1)
        fail("EVP_DigestSignUpdate failed");

    size_t sig_len = 0;
    if (EVP_DigestSignFinal(ctx, nullptr, &sig_len) != 1)
        fail("EVP_DigestSignFinal (size) failed");

    std::vector<unsigned char> signature(sig_len);
    if (EVP_DigestSignFinal(ctx, signature.data(), &sig_len) != 1)
        fail("EVP_DigestSignFinal failed");

    signature.resize(sig_len);

    EVP_MD_CTX_free(ctx);
    return signature;
}


int main(int argc, char *argv[])
{
    if (argc < 4)
    {
        std::cerr << "Usage:\n"
                  << "  " << argv[0] << " <pem_key> <file> <message>\n\n"
                  << "Example:\n"
                  << "  " << argv[0] << " ecdsa_priv.pem data.bin \"hello world\"\n";
        return 1;
    }

    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    std::string pem_path = argv[1];
    std::string file_path = argv[2];
    std::string message   = argv[3];

    // ---- Load ECDSA private key ----
    BIO *bio = BIO_new_file(pem_path.c_str(), "r");
    if (!bio)
        fail("Failed to open PEM file");

    EVP_PKEY *pkey = PEM_read_bio_PrivateKey(bio, nullptr, nullptr, nullptr);
    BIO_free(bio);
    if (!pkey)
        fail("Failed to read private key from PEM");

    // ---- Read file ----
    std::vector<unsigned char> file_data = read_file(file_path);

    // ---- Prepare message for challenge-response authentication
    std::cout << "Nonce received, preparing to sing nonce||timestamp \n" << std::endl; 
    std::vector<unsigned char> nonce(message.begin(), message.end());
    std::string timestamp;

    // ---- Sign both ----
    std::vector<unsigned char> sig_file = ecdsa_sign(pkey, file_data); //signs the file with the private key
    std::vector<unsigned char> sig_challenge =sign_challenge(pkey,nonce,timestamp); //sings the challeng with the same key, Pitfall AsymAuth

    // ---- Output ----
    print_hex("File signature : ", sig_file.data(), sig_file.size());
    print_hex("Challenge response sig.   : ", sig_challenge.data(), sig_challenge.size());

    std::ofstream f1("file_signature.bin", std::ios::binary);
    f1.write((char *)sig_file.data(), sig_file.size());
    f1.close();



    std::cout << "Saved file_signature.bin\n";

    EVP_PKEY_free(pkey);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
