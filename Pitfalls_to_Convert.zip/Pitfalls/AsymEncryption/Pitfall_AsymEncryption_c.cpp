#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <memory>

static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) throw std::runtime_error("Cannot open file: " + path);
    return {std::istreambuf_iterator<char>(file), {}};
}

int main() {
    const std::string privkey_path = "privkey.pem";
    const std::string cipher_path  = "ciphertext_modified_begining.bin";

    try {
        // === Load private key ===
        std::unique_ptr<BIO, decltype(&BIO_free)> keybio(
            BIO_new_file(privkey_path.c_str(), "r"), BIO_free);
        if (!keybio) throw std::runtime_error("Failed to open private key file");

        std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)> pkey(
            PEM_read_bio_PrivateKey(keybio.get(), nullptr, nullptr, nullptr), EVP_PKEY_free);
        if (!pkey) throw std::runtime_error("Failed to read private key");

        // === Read ciphertext ===
        std::vector<unsigned char> ciphertext = read_file(cipher_path);

        // === Create decryption context ===
        std::unique_ptr<EVP_PKEY_CTX, decltype(&EVP_PKEY_CTX_free)> ctx(
            EVP_PKEY_CTX_new_from_pkey(nullptr, pkey.get(), nullptr), EVP_PKEY_CTX_free);
        if (!ctx) throw std::runtime_error("Failed to create EVP_PKEY_CTX");

        if (EVP_PKEY_decrypt_init(ctx.get()) <= 0)
            throw std::runtime_error("EVP_PKEY_decrypt_init failed");

        // Set RSA padding mode to OAEP
        if (EVP_PKEY_CTX_set_rsa_padding(ctx.get(), RSA_PKCS1_OAEP_PADDING) <= 0)
            throw std::runtime_error("Failed to set OAEP padding");

        // Set OAEP digest to SHA-256 
        if (EVP_PKEY_CTX_set_rsa_oaep_md(ctx.get(), EVP_sha256()) <= 0)
            throw std::runtime_error("Failed to set OAEP hash to SHA-256");

        // === Determine output length ===
        size_t outlen = 0;
        if (EVP_PKEY_decrypt(ctx.get(), nullptr, &outlen, ciphertext.data(), ciphertext.size()) <= 0)
            throw std::runtime_error("Failed to get output length");

        std::vector<unsigned char> plaintext(outlen);

        // === Decrypt ===
        if (EVP_PKEY_decrypt(ctx.get(), plaintext.data(), &outlen,
                             ciphertext.data(), ciphertext.size()) <= 0)
        {
            unsigned long err = ERR_get_error();
            char buf[256];
            ERR_error_string_n(err, buf, sizeof(buf));
            throw std::runtime_error(std::string("Decryption failed: ") + buf);
        }

        plaintext.resize(outlen);
        std::cout << std::string(plaintext.begin(), plaintext.end()) << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
