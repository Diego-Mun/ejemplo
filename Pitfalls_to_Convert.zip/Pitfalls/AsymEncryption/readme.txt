Esta pitfall se basa en no dar información sobre el formato de padding al descifrar. El caso de pkcs7 ya está cubierto por la nota 37. 
En este caso nos centramos en el padding OAEP. En la versión buena el error que devuelve es el mismo "error:02000079:rsa routines::oaep decoding error"
independientemente de si el padding. La versión mala comprueba explícitamete el padding y si es incorrecto devuelve un código de error al respecto. 

Pitfall_AsymEncryption_c.cpp -> no padding check
Pitfall_AsymEncryption_nc.cpp -> 132-141 checks padding, 26-86 function to check if padding nc
