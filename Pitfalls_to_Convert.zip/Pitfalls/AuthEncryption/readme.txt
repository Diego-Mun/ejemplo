Esta pitfall se basa en devolver un código de error al comprobar el MAC. La buena no devuelve nada y la mala sí.

Pitfall_AuthEncryption_c.cpp -> No devuelve ninǵun código de error específico
Pitfall_AuthEncryption_nc.cpp -> 159-166 devuelve un error específico si el MAC es incorrecto