// aes_gcm_blind.cpp
// Decrypt AES-GCM but do not leak specific failure reasons.
// Usage:
//   g++ aes_gcm_blind.cpp -o aes_gcm_blind -lcrypto -std=c++17
//   ./aes_gcm_blind <key_hex> <iv_hex(12bytes)> <cipherfile> [aad_hex]
// Expected input file format: CIPHERTEXT || TAG(16 bytes)
// On any failure the program prints only a generic message.

#include <openssl/evp.h>
#include <openssl/provider.h>

#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

// Convert hex string (spaces allowed) to bytes. Throws on malformed hex.
static std::vector<unsigned char> hex_to_bytes(const std::string& hex_in) {
    std::string hex;
    hex.reserve(hex_in.size());
    for (char c : hex_in) if (!std::isspace(static_cast<unsigned char>(c))) hex.push_back(c);
    if (hex.size() % 2 != 0) throw std::runtime_error("badhex");
    std::vector<unsigned char> out(hex.size()/2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int val;
        if (std::sscanf(hex.c_str() + 2*i, "%2x", &val) != 1) throw std::runtime_error("badhex");
        out[i] = static_cast<unsigned char>(val);
    }
    return out;
}

// Read whole file, throw on error.
static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream ifs(path, std::ios::binary | std::ios::ate);
    if (!ifs) throw std::runtime_error("io");
    std::streamsize sz = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    if (sz < 0) sz = 0;
    std::vector<unsigned char> v((size_t)sz);
    if (sz > 0 && !ifs.read(reinterpret_cast<char*>(v.data()), sz)) throw std::runtime_error("io");
    return v;
}

int main(int argc, char* argv[]) {
    // Generic fail message used for any error (no specifics).
    const char *GENERIC_FAIL = "Decryption failed.\n";

    if (argc < 4 || argc > 5) {
        std::cerr << GENERIC_FAIL;
        return 1;
    }

    try {
        std::string keyhex  = argv[1];
        std::string ivhex   = argv[2];
        std::string infile  = argv[3];
        std::string aadhex  = (argc == 5) ? argv[4] : "";

        // Load default provider (best-effort). If this fails, we still hide details.
        OSSL_PROVIDER* def = OSSL_PROVIDER_load(nullptr, "default");
        if (!def) { std::cerr << GENERIC_FAIL; return 1; }

        // Parse inputs (may throw)
        std::vector<unsigned char> key = hex_to_bytes(keyhex);
        std::vector<unsigned char> iv  = hex_to_bytes(ivhex);
        std::vector<unsigned char> aad;
        if (!aadhex.empty()) aad = hex_to_bytes(aadhex);

        // Read file
        std::vector<unsigned char> file = read_file(infile);

        // Basic validation: key length must be 16/24/32, iv 12, file >= tag
        if (!(key.size() == 16 || key.size() == 24 || key.size() == 32) || iv.size() != 12 || file.size() < 16) {
            OSSL_PROVIDER_unload(def);
            std::cerr << GENERIC_FAIL;
            return 1;
        }

        // Split ciphertext and tag (last 16 bytes)
        const size_t tag_len = 16;
        std::vector<unsigned char> tag(file.end() - tag_len, file.end());
        std::vector<unsigned char> ct(file.begin(), file.end() - tag_len);

        // Choose cipher
        const EVP_CIPHER* cipher = nullptr;
        if (key.size() == 16) cipher = EVP_aes_128_gcm();
        else if (key.size() == 24) cipher = EVP_aes_192_gcm();
        else cipher = EVP_aes_256_gcm();

        // Create context
        EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
        if (!raw) { OSSL_PROVIDER_unload(def); std::cerr << GENERIC_FAIL; return 1; }
        std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)> ctx(raw, EVP_CIPHER_CTX_free);

        // Init decryption
        if (EVP_DecryptInit_ex2(ctx.get(), cipher, key.data(), iv.data(), nullptr) != 1) {
            OSSL_PROVIDER_unload(def); std::cerr << GENERIC_FAIL; return 1;
        }

        int outlen = 0;
        std::vector<unsigned char> pt(ct.size());

        // Process AAD if provided (ignore errors but treat as failure)
        if (!aad.empty()) {
            if (EVP_DecryptUpdate(ctx.get(), nullptr, &outlen, aad.data(), (int)aad.size()) != 1) {
                OSSL_PROVIDER_unload(def); std::cerr << GENERIC_FAIL; return 1;
            }
        }

        // Decrypt ciphertext (if any)
        if (!ct.empty()) {
            if (EVP_DecryptUpdate(ctx.get(), pt.data(), &outlen, ct.data(), (int)ct.size()) != 1) {
                OSSL_PROVIDER_unload(def); std::cerr << GENERIC_FAIL; return 1;
            }
        }
        int tot = outlen;

        // Set expected tag
        if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, (int)tag_len, tag.data()) != 1) {
            OSSL_PROVIDER_unload(def); std::cerr << GENERIC_FAIL; return 1;
        }

        // Finalize: verifies tag; returns 1 on success, 0 on failure.
        int ret = EVP_DecryptFinal_ex(ctx.get(), pt.data() + tot, &outlen);
        if (ret != 1) {
            OSSL_PROVIDER_unload(def);
            std::cerr << GENERIC_FAIL; // No further details
            return 1;
        }
        tot += outlen;
        pt.resize(tot);

        // Success: print plaintext (as ASCII-safe) but no extra diagnostic info
        for (unsigned char c : pt) std::cout << (std::isprint(c) ? (char)c : '.');
        std::cout << std::endl;

        OSSL_PROVIDER_unload(def);
        return 0;

    } catch (...) {
        // Any exception -> generic failure without details
        std::cerr << "Decryption failed.\n";
        return 1;
    }
}
