// aes_gcm_check.cpp
// Decrypt AES-GCM ciphertext and explicitly verify the authentication tag (MAC).
// Usage:
//   g++ aes_gcm_check.cpp -o aes_gcm_check -lcrypto -std=c++17
//   ./aes_gcm_check <key_hex> <iv_hex_12bytes> <cipherfile> [aad_hex]
// The ciphertext file format expected: CIPHERTEXT || TAG(16 bytes)

#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/provider.h>

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// Print OpenSSL errors with a label.
static void print_errors(const char* where) {
    unsigned long e;
    std::cerr << "[OpenSSL] " << where << ":\n";
    while ((e = ERR_get_error()) != 0) {
        std::cerr << "  - " << ERR_error_string(e, nullptr) << "\n";
    }
}

// Helper: hex string (spaces allowed) -> bytes
static std::vector<unsigned char> hex_to_bytes(const std::string& hex_in) {
    std::string hex;
    hex.reserve(hex_in.size());
    for (char c : hex_in) if (!std::isspace(static_cast<unsigned char>(c))) hex.push_back(c);
    if (hex.size() % 2 != 0) throw std::invalid_argument("hex string length must be even");
    std::vector<unsigned char> out(hex.size()/2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int val;
        if (std::sscanf(hex.c_str() + 2*i, "%2x", &val) != 1)
            throw std::invalid_argument("invalid hex digit");
        out[i] = static_cast<unsigned char>(val);
    }
    return out;
}

// Read a whole binary file into vector
static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream ifs(path, std::ios::binary | std::ios::ate);
    if (!ifs) throw std::runtime_error("failed to open file: " + path);
    std::streamsize sz = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    if (sz < 0) sz = 0;
    std::vector<unsigned char> v((size_t)sz);
    if (sz > 0 && !ifs.read(reinterpret_cast<char*>(v.data()), sz))
        throw std::runtime_error("file read error");
    return v;
}

int main(int argc, char* argv[]) {
    if (argc < 4 || argc > 5) {
        std::cerr << "Usage: " << argv[0] << " <key_hex> <iv_hex(12 bytes)> <cipherfile> [aad_hex]\n";
        return 1;
    }

    try {
        std::string keyhex = argv[1];
        std::string ivhex  = argv[2];
        std::string filename = argv[3];
        std::string aadhex = (argc == 5) ? argv[4] : "";

        // Load default provider
        OSSL_PROVIDER* def = OSSL_PROVIDER_load(nullptr, "default");
        if (!def) {
            print_errors("OSSL_PROVIDER_load(default)");
            return 2;
        }

        // Parse key and IV
        std::vector<unsigned char> key = hex_to_bytes(keyhex);
        std::vector<unsigned char> iv  = hex_to_bytes(ivhex);
        if (!(key.size() == 16 || key.size() == 24 || key.size() == 32)) {
            std::cerr << "Key must be 16/24/32 bytes (AES-128/192/256)\n";
            OSSL_PROVIDER_unload(def);
            return 3;
        }
        if (iv.size() != 12) {
            std::cerr << "IV must be 12 bytes for GCM (96 bits), provided: " << iv.size() << "\n";
            OSSL_PROVIDER_unload(def);
            return 4;
        }

        // Read ciphertext file
        std::vector<unsigned char> file = read_file(filename);
        if (file.size() < 16) {
            std::cerr << "Cipher file too short: must contain at least a 16-byte tag\n";
            OSSL_PROVIDER_unload(def);
            return 5;
        }

        // Split: last 16 bytes = tag, rest = ciphertext
        const size_t tag_len = 16;
        std::vector<unsigned char> tag(file.end() - tag_len, file.end());
        std::vector<unsigned char> ct(file.begin(), file.end() - tag_len);

        // Optional AAD
        std::vector<unsigned char> aad;
        if (!aadhex.empty()) aad = hex_to_bytes(aadhex);

        // Choose cipher by key length
        const EVP_CIPHER* cipher = nullptr;
        if (key.size() == 16) cipher = EVP_aes_128_gcm();
        else if (key.size() == 24) cipher = EVP_aes_192_gcm();
        else cipher = EVP_aes_256_gcm();

        // Prepare context
        EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
        if (!raw) { print_errors("EVP_CIPHER_CTX_new"); OSSL_PROVIDER_unload(def); return 6; }
        std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)> ctx(raw, EVP_CIPHER_CTX_free);

        // Initialize decryption
        if (EVP_DecryptInit_ex2(ctx.get(), cipher, key.data(), iv.data(), nullptr) != 1) {
            print_errors("EVP_DecryptInit_ex2");
            OSSL_PROVIDER_unload(def);
            return 7;
        }

        int outlen = 0;
        std::vector<unsigned char> pt(ct.size());

        // Provide AAD (if any) - AAD is processed before ciphertext
        if (!aad.empty()) {
            if (EVP_DecryptUpdate(ctx.get(), nullptr, &outlen, aad.data(), (int)aad.size()) != 1) {
                print_errors("EVP_DecryptUpdate (AAD)");
                OSSL_PROVIDER_unload(def);
                return 8;
            }
        }

        // Decrypt ciphertext
        if (!ct.empty()) {
            if (EVP_DecryptUpdate(ctx.get(), pt.data(), &outlen, ct.data(), (int)ct.size()) != 1) {
                print_errors("EVP_DecryptUpdate (ciphertext)");
                OSSL_PROVIDER_unload(def);
                return 9;
            }
        }
        int tot = outlen;

        // Set expected tag before finalizing
        // Use EVP_CIPHER_CTX_ctrl with EVP_CTRL_GCM_SET_TAG
        if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, (int)tag_len, tag.data()) != 1) {
            print_errors("EVP_CIPHER_CTX_ctrl(GCM_SET_TAG)");
            OSSL_PROVIDER_unload(def);
            return 10;
        }

        // Finalize: this will verify tag; returns 1 on success, 0 on failure (tag mismatch)
        int ret = EVP_DecryptFinal_ex(ctx.get(), pt.data() + tot, &outlen);
        if (ret != 1) {
            // Authentication failed (tag mismatch)
            std::cerr << "Authentication failed: tag mismatch (ciphertext tampered or wrong key/IV/AAD).\n";
            // Print OpenSSL error stack for debugging (optional)
            print_errors("EVP_DecryptFinal_ex");
            OSSL_PROVIDER_unload(def);
            return 11;
        }
        /*
        Pitfall AuthEncryption it returns an error code for TAG
        */
        tot += outlen;
        pt.resize(tot);

        // Success: print plaintext (hex + printable)
        std::cout << "Decryption successful. Plaintext (" << pt.size() << " bytes):\n";
        // Hex
        std::cout << "HEX: ";
        std::ostringstream oss;
        oss << std::hex << std::setfill('0');
        for (unsigned char b : pt) oss << std::setw(2) << (int)b;
        std::cout << oss.str() << "\n";
        // ASCII-safe
        std::cout << "ASCII: ";
        for (unsigned char c : pt) std::cout << (std::isprint(c) ? (char)c : '.');
        std::cout << "\n";

        OSSL_PROVIDER_unload(def);
        return 0;

    } catch (const std::exception& ex) {
        std::cerr << "Exception: " << ex.what() << "\n";
        return 99;
    }
}
