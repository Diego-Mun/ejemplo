#include <openssl/evp.h>
#include <openssl/core_names.h>
#include <openssl/ec.h>
#include <openssl/err.h>
#include <openssl/param_build.h>

#include <iostream>
#include <fstream>
#include <string>

static void handleErrors(const char* msg) {
    unsigned long err = ERR_get_error();
    std::cerr << msg << "\n";
    if (err) {
        char buf[256];
        ERR_error_string_n(err, buf, sizeof(buf));
        std::cerr << "OpenSSL error: " << buf << "\n";
    }
    exit(EXIT_FAILURE);
}

std::string read_file_trim(const char* filename) {
    std::ifstream ifs(filename);
    if (!ifs.is_open()) return "";
    std::string s;
    std::getline(ifs, s);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ' || s.back() == '\t'))
        s.pop_back();
    return s;
}

int main() {
    ERR_load_crypto_strings();

    EVP_PKEY_CTX *genctx = nullptr;
    EVP_PKEY *key = nullptr;

    // 1. Generate EC keypair (P-384)
    genctx = EVP_PKEY_CTX_new_from_name(nullptr, "EC", nullptr);
    if (!genctx) handleErrors("EVP_PKEY_CTX_new_from_name failed");
    if (EVP_PKEY_keygen_init(genctx) <= 0) handleErrors("EVP_PKEY_keygen_init failed");
    if (EVP_PKEY_CTX_set_ec_paramgen_curve_nid(genctx, NID_secp384r1) <= 0)
        handleErrors("Setting curve failed");
    if (EVP_PKEY_generate(genctx, &key) <= 0)
        handleErrors("EVP_PKEY_generate failed");
    EVP_PKEY_CTX_free(genctx);

    // 2. Extract EC_KEY (for low-level ops like EC_POINT)
    EC_KEY *ec = EVP_PKEY_get1_EC_KEY(key);
    if (!ec) handleErrors("EVP_PKEY_get1_EC_KEY failed");

    const EC_GROUP *group = EC_KEY_get0_group(ec);
    const EC_POINT *pub = EC_KEY_get0_public_key(ec);
    const BIGNUM *priv_bn = EC_KEY_get0_private_key(ec);

    BN_CTX *ctx = BN_CTX_new();
    char *our_pub_hex = EC_POINT_point2hex(group, pub, POINT_CONVERSION_UNCOMPRESSED, ctx);
    std::cout << "Our public key (hex):\n" << our_pub_hex << "\n\n";

    // 3. Read peer pub from file
    std::string peer_hex = read_file_trim("peer_pub.hex");
    if (peer_hex.empty()) {
        std::cout << "peer_pub.hex not found -> simulating with our own pub\n";
        peer_hex = std::string(our_pub_hex);
    }

    EC_POINT *peer_point = EC_POINT_new(group);
    if (!peer_point) handleErrors("EC_POINT_new failed");
    if (!EC_POINT_hex2point(group, peer_hex.c_str(), peer_point, ctx))
        handleErrors("EC_POINT_hex2point failed");

        /*
        Does not check if the point belongs to the curve. 
        */

    // 5. Compute shared point = priv * peer
    EC_POINT *shared_point = EC_POINT_new(group);
    if (!shared_point) handleErrors("EC_POINT_new failed (shared)");
    if (!EC_POINT_mul(group, shared_point, NULL, peer_point, priv_bn, ctx))
        handleErrors("EC_POINT_mul failed");

    char *shared_hex = EC_POINT_point2hex(group, shared_point, POINT_CONVERSION_UNCOMPRESSED, ctx);
    std::cout << "\nShared point (hex):\n" << shared_hex << "\n";

    // Cleanup
    OPENSSL_free(our_pub_hex);
    OPENSSL_free(shared_hex);
    EC_POINT_free(peer_point);
    EC_POINT_free(shared_point);
    EC_KEY_free(ec);
    EVP_PKEY_free(key);
    BN_CTX_free(ctx);
    ERR_free_strings();

    return 0;
}
