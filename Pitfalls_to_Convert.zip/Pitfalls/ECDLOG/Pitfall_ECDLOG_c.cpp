#include <openssl/evp.h>
#include <openssl/core_names.h>
#include <openssl/ec.h>
#include <openssl/param_build.h>
#include <openssl/err.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>

// Print hex helper
std::string to_hex(const std::vector<unsigned char>& data) {
    std::ostringstream oss;
    for (auto b : data)
        oss << std::hex << std::setfill('0') << std::setw(2) << (int)b;
    return oss.str();
}

std::string read_file_trim(const char* filename) {
    std::ifstream ifs(filename);
    if (!ifs.is_open()) return "";
    std::string s;
    std::getline(ifs, s);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' ||
                          s.back() == ' ' || s.back() == '\t'))
        s.pop_back();
    return s;
}

static void handleErrors(const char* msg) {
    std::cerr << msg << "\n";
    unsigned long err;
    while ((err = ERR_get_error())) {
        char buf[256];
        ERR_error_string_n(err, buf, sizeof(buf));
        std::cerr << "OpenSSL: " << buf << "\n";
    }
    exit(EXIT_FAILURE);
}

int main() {
    ERR_load_crypto_strings();

    // 1. Build params for EC key generation (curve = secp384r1)
    OSSL_PARAM_BLD *bld = OSSL_PARAM_BLD_new();
    OSSL_PARAM_BLD_push_utf8_string(bld, OSSL_PKEY_PARAM_GROUP_NAME, "secp384r1", 0);
    OSSL_PARAM *params = OSSL_PARAM_BLD_to_param(bld);

    // 2. Generate our keypair
    EVP_PKEY_CTX *genctx = EVP_PKEY_CTX_new_from_name(nullptr, "EC", nullptr);
    EVP_PKEY_keygen_init(genctx);
    EVP_PKEY_CTX_set_params(genctx, params);
    EVP_PKEY *mykey = nullptr;
    if (EVP_PKEY_generate(genctx, &mykey) <= 0)
        handleErrors("Key generation failed");

    OSSL_PARAM_free(params);
    OSSL_PARAM_BLD_free(bld);
    EVP_PKEY_CTX_free(genctx);

    // 3. Export our public key in octet form
    size_t pub_len = 0;
    EVP_PKEY_get_octet_string_param(mykey, OSSL_PKEY_PARAM_PUB_KEY, nullptr, 0, &pub_len);
    std::vector<unsigned char> pub_bytes(pub_len);
    EVP_PKEY_get_octet_string_param(mykey, OSSL_PKEY_PARAM_PUB_KEY,
                                    pub_bytes.data(), pub_bytes.size(), &pub_len);
    std::string pub_hex = to_hex(pub_bytes);
    std::cout << "Our public key:\n" << pub_hex << "\n\n";

    // 4. Read peer point
    std::string peer_hex = read_file_trim("peer_pub_modified.hex");
    if (peer_hex.empty()) {
        std::cout << "peer_pub.hex not found, using self.\n";
        peer_hex = pub_hex;
    }

    // Convert hex to bytes
    std::vector<unsigned char> peer_bytes;
    peer_bytes.reserve(peer_hex.size() / 2);
    for (size_t i = 0; i < peer_hex.size(); i += 2)
        peer_bytes.push_back((unsigned char)std::stoul(peer_hex.substr(i, 2), nullptr, 16));

    // 5. Explicit validation of peer point, this avoids pitfall ECDLOG
    // Create EC_GROUP for secp384r1
    EC_GROUP *group = EC_GROUP_new_by_curve_name(NID_secp384r1);
    if (!group) handleErrors("EC_GROUP_new_by_curve_name failed");

    BN_CTX *ctx = BN_CTX_new();
    EC_POINT *peer_point = EC_POINT_new(group);
    if (!EC_POINT_oct2point(group, peer_point, peer_bytes.data(), peer_bytes.size(), ctx))
        handleErrors("EC_POINT_oct2point: invalid encoding");

    int valid = EC_POINT_is_on_curve(group, peer_point, ctx);
    if (valid != 1) {
        std::cerr << "❌ Peer point is NOT on secp384r1 — aborting.\n";
        return EXIT_FAILURE;
    }
    std::cout << "✅ Peer point validated: lies on secp384r1.\n";

    // 6. Re-import peer into EVP_PKEY for ECDH derive
    OSSL_PARAM_BLD *peer_bld = OSSL_PARAM_BLD_new();
    OSSL_PARAM_BLD_push_utf8_string(peer_bld, OSSL_PKEY_PARAM_GROUP_NAME, "secp384r1", 0);
    OSSL_PARAM_BLD_push_octet_string(peer_bld, OSSL_PKEY_PARAM_PUB_KEY,
                                     peer_bytes.data(), peer_bytes.size());
    OSSL_PARAM *peer_params = OSSL_PARAM_BLD_to_param(peer_bld);
    EVP_PKEY *peerkey = nullptr;
    EVP_PKEY_CTX *peerctx = EVP_PKEY_CTX_new_from_name(nullptr, "EC", nullptr);
    EVP_PKEY_fromdata_init(peerctx);
    if (EVP_PKEY_fromdata(peerctx, &peerkey, EVP_PKEY_PUBLIC_KEY, peer_params) <= 0)
        handleErrors("EVP_PKEY_fromdata failed (after validation)");

    // 7. Derive shared secret
    EVP_PKEY_CTX *derive_ctx = EVP_PKEY_CTX_new(mykey, nullptr);
    EVP_PKEY_derive_init(derive_ctx);
    EVP_PKEY_derive_set_peer(derive_ctx, peerkey);
    size_t secret_len = 0;
    EVP_PKEY_derive(derive_ctx, nullptr, &secret_len);
    std::vector<unsigned char> secret(secret_len);
    EVP_PKEY_derive(derive_ctx, secret.data(), &secret_len);
    secret.resize(secret_len);

    std::cout << "\nShared secret (" << secret_len << " bytes):\n"
              << to_hex(secret) << "\n";

    // Cleanup
    EVP_PKEY_free(mykey);
    EVP_PKEY_free(peerkey);
    EVP_PKEY_CTX_free(peerctx);
    EVP_PKEY_CTX_free(derive_ctx);
    EC_POINT_free(peer_point);
    EC_GROUP_free(group);
    BN_CTX_free(ctx);

    return 0;
}
