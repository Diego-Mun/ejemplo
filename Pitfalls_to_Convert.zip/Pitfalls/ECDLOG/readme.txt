Esta pitfall se basa en no comprobar que los puntos recibidos de otras entidades corresponden a la curva correcta antes de manipularlo. 
En concreto recibe un punto como parte de un ECDH, comprueba que esté en la curva y si lo está lo multiplica por su exponente priv. Luego
hace output de este. La versión mala no hace comprobaciones, tiene muchas funciones deprecated porque las funciones modernas comprueban 
el punto directamente. 

Pitfall_ECDLOG_c.cpp -> 83-99 Comprueba explícitamente que los puntos estén en la curva
Pitfall_ECDLOG_nc.cpp -> No se comprueba en ninguna línea 
