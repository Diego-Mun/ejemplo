Esta pitfall se basa en no comprobar que la longiud del parámetro r (mayor factor primo de q, orden del subgrupo sobre el que se opera) sea de al menos 200 bits.
La versión buena genera un grupo finito, extrae q y calcula la longitud mínima de r. La versión mala no lo hace. Esto es la primitiva, así que vale tanto
para DH como para DSA. Nótese que en la vida real los grupos no se calculan, se usan los estándar. 

Pitfall_FFDLOG1_c.cpp -> líneas 65-78 se calcula r y se comprueba su longitd
Pitfall_FFDLOG1_nc.cpp -> líneas 58-69 se calcula el grupo y se manda todo sin comprobar nada
