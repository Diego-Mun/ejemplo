#include <openssl/bn.h>
#include <openssl/err.h>
#include <iostream>
#include <vector>

// Helper to print a BIGNUM in hex
void printBN(const char* label, const BIGNUM* bn) {
    char* hex = BN_bn2hex(bn);
    std::cout << label << ": " << hex << std::endl;
    OPENSSL_free(hex);
}

// Very naive function to find large prime factors of q
// (for real use, you'd use a proper safe-prime generation)
BIGNUM* largest_prime_factor(const BIGNUM* q, BN_CTX* ctx) {
    BIGNUM *factor = BN_new();
    BIGNUM *rem = BN_new();
    BIGNUM *tmp = BN_dup(q);
    BIGNUM *two = BN_new();
    BN_set_word(two, 2);

    // remove factors of 2
    while (BN_is_odd(tmp) == 0) {
        BN_div(tmp, rem, tmp, two, ctx);
    }

    // try odd divisors up to 2^20 (toy bound)
    BIGNUM *i = BN_new();
    BN_set_word(i, 3);
    BIGNUM *limit = BN_new();
    BN_set_word(limit, 1 << 20);

    while (BN_cmp(i, limit) < 0) {
        BN_mod(rem, tmp, i, ctx);
        if (BN_is_zero(rem)) {
            BN_div(tmp, rem, tmp, i, ctx);
            BN_copy(factor, i);
        }
        BN_add(i, i, two);
    }

    if (BN_cmp(tmp, factor) > 0)
        BN_copy(factor, tmp); // last large factor

    BN_free(rem); BN_free(two); BN_free(tmp); BN_free(i); BN_free(limit);
    return factor;
}

int main() {
    BN_CTX* ctx = BN_CTX_new();

    // 1. Generate a 2048-bit prime p
    BIGNUM* p = BN_new();
    if (!BN_generate_prime_ex(p, 2048, 1, NULL, NULL, NULL)) {
        std::cerr << "Prime generation failed." << std::endl;
        return 1;
    }
    printBN("p", p);

    // 2. q = p - 1
    BIGNUM* q = BN_new();
    BN_copy(q, p);
    BN_sub_word(q, 1);


    // 5. Pick g = 2 and test that g^r mod p != 1
    BIGNUM* g = BN_new();
    BN_set_word(g, 2);



    printBN("g", g);

    // Cleanup
    BN_free(p); BN_free(q); BN_free(g);
    BN_CTX_free(ctx);
    return 0;
}
