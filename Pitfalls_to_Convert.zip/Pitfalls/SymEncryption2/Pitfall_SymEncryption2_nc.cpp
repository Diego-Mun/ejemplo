// Compile:
//   g++ aes128_cbc_decrypt_check_padding.cpp -o aes_cbc_check -lcrypto -std=c++17
//
// Usage:
//   ./aes_cbc_check <key_hex_16bytes> <iv_hex_16bytes> [ciphertext.bin]
// The input file must contain only the ciphertext (no IV, no "Salted__" header).

#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/provider.h>

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// Print OpenSSL errors with a label.
static void print_errors(const char* where) {
    unsigned long e;
    std::cerr << "[OpenSSL] " << where << ":\n";
    while ((e = ERR_get_error()) != 0) {
        std::cerr << "  - " << ERR_error_string(e, nullptr) << "\n";
    }
}

// Throw on failure, printing OpenSSL errors.
static void ensure(bool ok, const char* where) {
    if (!ok) {
        print_errors(where);
        throw std::runtime_error(where);
    }
}

// Convert hex string (possibly containing spaces) to bytes.
static std::vector<unsigned char> hex_to_bytes(const std::string& hex_in) {
    std::string hex;
    hex.reserve(hex_in.size());
    for (char c : hex_in) {
        if (!std::isspace(static_cast<unsigned char>(c)))
            hex.push_back(c);
    }
    if (hex.size() % 2 != 0)
        throw std::invalid_argument("hex string length must be even");
    std::vector<unsigned char> out(hex.size() / 2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int val;
        if (std::sscanf(hex.c_str() + 2 * i, "%2x", &val) != 1)
            throw std::invalid_argument("invalid hex digit");
        out[i] = static_cast<unsigned char>(val);
    }
    return out;
}

// Hex dump helper
static std::string to_hex(const std::vector<unsigned char>& v) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (unsigned char b : v) oss << std::setw(2) << (int)b;
    return oss.str();
}

// Read whole file to vector
static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream ifs(path, std::ios::binary | std::ios::ate);
    if (!ifs) throw std::runtime_error("failed to open file: " + path);
    std::streamsize sz = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    if (sz < 0) throw std::runtime_error("file size error");
    std::vector<unsigned char> data((size_t)sz);
    if (!ifs.read(reinterpret_cast<char*>(data.data()), sz)) throw std::runtime_error("file read error");
    return data;
}

// Manual PKCS#7 validation: check and strip padding from buffer.
// If invalid => throw runtime_error with explanation.
static std::vector<unsigned char> strip_pkcs7_padding(std::vector<unsigned char>& buf, size_t block_size) {
    if (buf.empty() || (buf.size() % block_size) != 0)
        throw std::runtime_error("plaintext length not multiple of block size for padding check");

    unsigned char pad = buf.back();
    if (pad == 0 || pad > block_size)
        throw std::runtime_error("Invalid PKCS#7 padding (pad value out of range)");

    size_t n = buf.size();
    // Check that the last 'pad' bytes are all equal to 'pad'
    for (size_t i = 0; i < static_cast<size_t>(pad); ++i) {
        if (buf[n - 1 - i] != pad)
            throw std::runtime_error("Invalid PKCS#7 padding (bytes mismatch)");
    }

    // Valid padding: remove it and return
    buf.resize(n - pad);
    return buf;
}

int main(int argc, char* argv[]) {
    try {
        if (argc < 3 || argc > 4) {
            std::cerr << "Usage: " << argv[0] << " <key_hex_16bytes> <iv_hex_16bytes> [ciphertext.bin]\n";
            std::cerr << "Note: ciphertext file must contain only ciphertext (no IV, no OpenSSL header)\n";
            return 1;
        }

        const std::string keyhex = argv[1];
        const std::string ivhex  = argv[2];
        const std::string filename = (argc == 4) ? argv[3] : "ciphertext.bin";

        // Load default provider (OpenSSL 3)
        OSSL_PROVIDER* defp = OSSL_PROVIDER_load(nullptr, "default");
        if (!defp) {
            print_errors("OSSL_PROVIDER_load(default)");
            return 2;
        }

        // Convert and validate key and IV lengths
        std::vector<unsigned char> key = hex_to_bytes(keyhex);
        std::vector<unsigned char> iv  = hex_to_bytes(ivhex);
        if (key.size() != 16) {
            std::cerr << "Key must be 16 bytes (AES-128). Provided: " << key.size() << " bytes\n";
            OSSL_PROVIDER_unload(defp);
            return 3;
        }
        if (iv.size() != 16) {
            std::cerr << "IV must be 16 bytes. Provided: " << iv.size() << " bytes\n";
            OSSL_PROVIDER_unload(defp);
            return 4;
        }

        // Read ciphertext file (only ciphertext bytes)
        std::vector<unsigned char> ct = read_file(filename);
        if (ct.empty() || (ct.size() % 16) != 0) {
            std::cerr << "Ciphertext invalid: must be non-empty and a multiple of 16 bytes\n";
            OSSL_PROVIDER_unload(defp);
            return 5;
        }

        // Prepare AES-128-CBC decrypt with padding disabled (we will validate manually)
        EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
        if (!raw) { print_errors("EVP_CIPHER_CTX_new"); OSSL_PROVIDER_unload(defp); return 6; }
        std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)> ctx(raw, EVP_CIPHER_CTX_free);

        ensure(EVP_DecryptInit_ex2(ctx.get(), EVP_aes_128_cbc(), key.data(), iv.data(), nullptr) == 1,
               "EVP_DecryptInit_ex2");
        // Disable automatic padding removal so OpenSSL does not touch padding bytes.
        ensure(EVP_CIPHER_CTX_set_padding(ctx.get(), 0) == 1, "EVP_CIPHER_CTX_set_padding");

        std::vector<unsigned char> pt(ct.size()); // decrypted buffer (contains padding)
        int outl = 0;
        ensure(EVP_DecryptUpdate(ctx.get(), pt.data(), &outl, ct.data(), (int)ct.size()) == 1, "EVP_DecryptUpdate");
        int tot = outl;

        // With padding disabled, DecryptFinal should succeed for correct block-aligned ciphertext.
        ensure(EVP_DecryptFinal_ex(ctx.get(), pt.data() + tot, &outl) == 1, "EVP_DecryptFinal_ex");
        tot += outl;
        pt.resize(tot);

        // Manual PKCS#7 validation
        try {
            std::vector<unsigned char> plain = strip_pkcs7_padding(pt, 16);

            // If we reach here padding is valid
            std::cout << "Padding valid. Plaintext (" << plain.size() << " bytes):\n";
            std::cout << "HEX: " << to_hex(plain) << "\n";
            std::cout << "ASCII: ";
            for (unsigned char c : plain) {
                if (std::isprint(c)) std::cout << static_cast<char>(c);
                else std::cout << '.';
            }
            std::cout << "\n";

            OSSL_PROVIDER_unload(defp);
            return 0;
        } catch (const std::exception& ex) {
            std::cerr << "Invalid padding: " << ex.what() << "\n";

            // Optional debugging: show the last up to 32 bytes of the decrypted buffer (with padding)
            if (!pt.empty()) {
                size_t dump = std::min<size_t>(pt.size(), 32);
                std::cerr << "Last " << dump << " bytes (hex) of decrypted buffer (includes padding):\n";
                size_t start = pt.size() - dump;
                std::vector<unsigned char> tail(pt.begin() + start, pt.end());
                std::cerr << to_hex(tail) << "\n";
            }

            OSSL_PROVIDER_unload(defp);
            return 7;
        }

    } catch (const std::exception& ex) {
        std::cerr << "Exception: " << ex.what() << "\n";
        return 99;
    }
}
