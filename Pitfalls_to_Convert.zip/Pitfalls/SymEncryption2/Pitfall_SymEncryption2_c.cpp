#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/provider.h>

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// Convert hex string to byte vector
static std::vector<unsigned char> hex_to_bytes(std::string hex) {
    hex.erase(std::remove_if(hex.begin(), hex.end(), ::isspace), hex.end());
    if (hex.size() % 2 != 0) throw std::invalid_argument("hex string length must be even");
    std::vector<unsigned char> out(hex.size() / 2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int val;
        if (std::sscanf(hex.c_str() + 2 * i, "%2x", &val) != 1)
            throw std::invalid_argument("invalid hex digit");
        out[i] = static_cast<unsigned char>(val);
    }
    return out;
}

// Read a binary file into memory
static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) throw std::runtime_error("cannot open file: " + path);
    std::streamsize sz = f.tellg();
    f.seekg(0, std::ios::beg);
    std::vector<unsigned char> data((size_t)sz);
    if (!f.read(reinterpret_cast<char*>(data.data()), sz))
        throw std::runtime_error("error reading file");
    return data;
}

int main(int argc, char* argv[]) {
    if (argc < 3 || argc > 4) {
        std::cerr << "Usage: " << argv[0] << " <key_hex_16bytes> <iv_hex_16bytes> [ciphertext.bin]\n";
        return 1;
    }

    try {
        const std::string keyhex = argv[1];
        const std::string ivhex  = argv[2];
        const std::string filename = (argc == 4) ? argv[3] : "ciphertext.bin";

        // Load default provider (OpenSSL 3)
        OSSL_PROVIDER* defprov = OSSL_PROVIDER_load(nullptr, "default");
        if (!defprov) {
            std::cerr << "Failed to load OpenSSL default provider.\n";
            return 2;
        }

        std::vector<unsigned char> key = hex_to_bytes(keyhex);
        std::vector<unsigned char> iv  = hex_to_bytes(ivhex);
        if (key.size() != 16 || iv.size() != 16)
            throw std::runtime_error("Key and IV must be 16 bytes each (AES-128)");

        std::vector<unsigned char> ct = read_file(filename);
        if (ct.empty()) throw std::runtime_error("Ciphertext file empty");

        // --- AES-128-CBC decrypt with padding enabled ---
        EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
        if (!raw) throw std::runtime_error("EVP_CIPHER_CTX_new failed");
        std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)>
            ctx(raw, EVP_CIPHER_CTX_free);

        if (EVP_DecryptInit_ex2(ctx.get(), EVP_aes_128_cbc(), key.data(), iv.data(), nullptr) != 1)
            throw std::runtime_error("EVP_DecryptInit_ex2 failed");

        // Padding is ON by default (PKCS#7)
        std::vector<unsigned char> pt(ct.size() + 16);
        int outl = 0, tot = 0;

        if (EVP_DecryptUpdate(ctx.get(), pt.data(), &outl, ct.data(), (int)ct.size()) != 1)
            throw std::runtime_error("EVP_DecryptUpdate failed");
        tot += outl;

        // EVP_DecryptFinal_ex performs PKCS#7 check
        int ret = EVP_DecryptFinal_ex(ctx.get(), pt.data() + tot, &outl);
        if (ret != 1) {
            // Generic failure message (no padding details)
            std::cerr << "Decryption failed\n";
            OSSL_PROVIDER_unload(defprov);
            return 3;
        }
        tot += outl;
        pt.resize(tot);

        std::cout << "Decryption successful. Plaintext (" << pt.size() << " bytes):\n";
        for (unsigned char c : pt)
            std::cout << (std::isprint(c) ? (char)c : '.');
        std::cout << "\n";

        OSSL_PROVIDER_unload(defprov);
        return 0;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 99;
    }
}
