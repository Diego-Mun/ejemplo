Esta pitfall se basa en devolver un código de error al encontrar un formato de padding incorrecto. La versión buena no lo hace la mala sí. 


Pitfall_SymEncryption2_nc.cpp -> 79-99 informa del formato de padding. 
Pitfall_SymEncryption2_c.cpp -> En ningún momento se da información sobre el error específico. 