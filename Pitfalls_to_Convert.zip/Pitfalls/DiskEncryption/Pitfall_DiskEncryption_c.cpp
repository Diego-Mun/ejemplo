#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/provider.h>

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdint>
#include <array>

// Print OpenSSL errors with a label
static void print_errors(const char* where) {
    unsigned long e;
    std::cerr << "[OpenSSL] " << where << ":\n";
    while ((e = ERR_get_error()) != 0) {
        std::cerr << "  - " << ERR_error_string(e, nullptr) << "\n";
    }
}

// Throw on failure and print OpenSSL errors
static void ensure(bool ok, const char* where) {
    if (!ok) {
        print_errors(where);
        throw std::runtime_error(where);
    }
}

// Convert hex string to bytes (ignores whitespace)
static std::vector<unsigned char> hex_to_bytes(const std::string& hex_in) {
    std::string hex;
    hex.reserve(hex_in.size());
    for (char c : hex_in) {
        if (!std::isspace(static_cast<unsigned char>(c))) hex.push_back(c);
    }
    if (hex.size() % 2 != 0) throw std::invalid_argument("hex length must be even");
    std::vector<unsigned char> out(hex.size()/2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int byte;
        if (std::sscanf(hex.c_str() + 2*i, "%2x", &byte) != 1)
            throw std::invalid_argument("invalid hex");
        out[i] = static_cast<unsigned char>(byte);
    }
    return out;
}

// Read entire file into vector
static std::vector<unsigned char> read_file(const std::string& path) {
    std::ifstream ifs(path, std::ios::binary | std::ios::ate);
    if (!ifs) throw std::runtime_error("cannot open input file: " + path);
    std::streamsize sz = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    if (sz < 0) sz = 0;
    std::vector<unsigned char> data((size_t)sz);
    if (sz > 0 && !ifs.read(reinterpret_cast<char*>(data.data()), sz))
        throw std::runtime_error("error reading input file");
    return data;
}

// Write bytes to file
static void write_file(const std::string& path, const std::vector<unsigned char>& data) {
    std::ofstream ofs(path, std::ios::binary);
    if (!ofs) throw std::runtime_error("cannot open output file: " + path);
    if (!data.empty() && !ofs.write(reinterpret_cast<const char*>(data.data()), data.size()))
        throw std::runtime_error("error writing output file");
}

// Derive 16-byte tweak from a 64-bit sector number.
// We place sector in little-endian into first 8 bytes, rest zeros.
// This is a typical approach for XTS tweaks (unit/sector number).
/*
Pitfall Disk Encryption avoided
*/
static std::array<unsigned char,16> tweak_from_sector(uint64_t sector) {
    std::array<unsigned char,16> tweak{};
    for (int i = 0; i < 8; ++i) {
        tweak[i] = static_cast<unsigned char>((sector >> (8*i)) & 0xFF);
    }
    // remaining bytes are zero
    return tweak;
}

int main(int argc, char* argv[]) {
    try {
        if (argc != 6) {
            std::cerr << "Usage: " << argv[0] << " <encrypt|decrypt> <key_hex_32or64bytes> <sector_number> <infile> <outfile>\n";
            return 1;
        }

        std::string op = argv[1];
        std::transform(op.begin(), op.end(), op.begin(), [](unsigned char c){ return std::tolower(c); });
        bool encrypt = false;
        if (op == "encrypt") encrypt = true;
        else if (op == "decrypt") encrypt = false;
        else {
            std::cerr << "Operation must be 'encrypt' or 'decrypt'\n";
            return 1;
        }

        std::string keyhex = argv[2];
        uint64_t sector = 0;
        {
            // parse sector (decimal) - accept decimal numbers
            std::string secstr = argv[3];
            try {
                size_t idx = 0;
                sector = std::stoull(secstr, &idx, 10);
            } catch (...) {
                throw std::invalid_argument("invalid sector number");
            }
        }
        std::string infile  = argv[4];
        std::string outfile = argv[5];

        // Load default provider
        OSSL_PROVIDER* defp = OSSL_PROVIDER_load(nullptr, "default");
        if (!defp) {
            print_errors("OSSL_PROVIDER_load(default)");
            return 2;
        }

        // Convert key hex
        std::vector<unsigned char> key = hex_to_bytes(keyhex);
        if (!(key.size() == 32 || key.size() == 64)) {
            std::cerr << "Key length must be 32 bytes (AES-128-XTS) or 64 bytes (AES-256-XTS). Provided: "
                      << key.size() << " bytes\n";
            OSSL_PROVIDER_unload(defp);
            return 3;
        }

        // Select cipher
        const EVP_CIPHER* cipher = nullptr;
        if (key.size() == 32) cipher = EVP_aes_128_xts();
        else cipher = EVP_aes_256_xts();

        // Read input
        std::vector<unsigned char> input = read_file(infile);
        /*
        PItfall DiskEncryption generates teh IV with the sector to be encrypted
        */
        // Prepare tweak/IV
        std::array<unsigned char,16> tweak = tweak_from_sector(sector);

        // Setup context
        EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
        ensure(raw != nullptr, "EVP_CIPHER_CTX_new");
        std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)> ctx(raw, EVP_CIPHER_CTX_free);

        // Initialize (note: for XTS the "iv" parameter is the tweak)
        if (encrypt) {
            ensure(EVP_EncryptInit_ex2(ctx.get(), cipher, key.data(), tweak.data(), nullptr) == 1,
                   "EVP_EncryptInit_ex2");
        } else {
            ensure(EVP_DecryptInit_ex2(ctx.get(), cipher, key.data(), tweak.data(), nullptr) == 1,
                   "EVP_DecryptInit_ex2");
        }

        // XTS is a tweakable cipher mode: no padding; ensure padding disabled
        ensure(EVP_CIPHER_CTX_set_padding(ctx.get(), 0) == 1, "EVP_CIPHER_CTX_set_padding");

        // Do the operation
        std::vector<unsigned char> out;
        out.resize(input.size() + EVP_CIPHER_block_size(cipher));
        int outl = 0;
        if (encrypt) {
            ensure(EVP_EncryptUpdate(ctx.get(), out.data(), &outl, input.data(), (int)input.size()) == 1,
                   "EVP_EncryptUpdate");
        } else {
            ensure(EVP_DecryptUpdate(ctx.get(), out.data(), &outl, input.data(), (int)input.size()) == 1,
                   "EVP_DecryptUpdate");
        }
        int tot = outl;

        if (encrypt) {
            ensure(EVP_EncryptFinal_ex(ctx.get(), out.data() + tot, &outl) == 1, "EVP_EncryptFinal_ex");
        } else {
            ensure(EVP_DecryptFinal_ex(ctx.get(), out.data() + tot, &outl) == 1, "EVP_DecryptFinal_ex");
        }
        tot += outl;
        out.resize(tot);

        // Write out file
        write_file(outfile, out);

        std::cout << (encrypt ? "Encryption" : "Decryption") << " completed.\n";
        std::cout << "Sector: " << sector << "  Tweak(hex): ";
        for (auto b : tweak) std::cout << std::hex << std::setfill('0') << std::setw(2) << (int)b;
        std::cout << std::dec << "\n";
        std::cout << "Input bytes: " << input.size() << "  Output bytes: " << out.size() << "\n";

        OSSL_PROVIDER_unload(defp);
        return 0;

    } catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << "\n";
        return 99;
    }
}
