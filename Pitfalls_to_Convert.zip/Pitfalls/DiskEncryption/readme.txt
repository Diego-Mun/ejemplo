Esta pitfall se basa en usar un IV estático para AES-XTS. La mala lo tiene fijo la buena lo deriva de la dirección de almacenamiento. 

Pitfall_DiskEncryption_c.cpp -> 73-86 el IV se deriva de la dirección de memoria.
Pitfall_DiskEncryption_nc.cpp -> 130-138 el IV es estático
