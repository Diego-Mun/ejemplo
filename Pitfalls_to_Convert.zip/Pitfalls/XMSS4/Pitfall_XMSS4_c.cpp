#include <botan/auto_rng.h>
#include <botan/xmss.h>
#include <botan/pk_ops.h>       // <- Required for PK_Ops::Signature/Verification
#include <botan/hex.h>
#include <fstream>
#include <iostream>


int main(int argc, char* argv[]) {

    try {
        Botan::AutoSeeded_RNG rng;

        // 1) Generate XMSS key (NIST SP 800-208 derivation by default in Botan 3)
        Botan::XMSS_PrivateKey priv(
            Botan::XMSS_Parameters::xmss_algorithm_t::XMSS_SHAKE_10_256, //Pitfall XMSS4 avoided, uses shake256
            rng);

        std::unique_ptr<Botan::Public_Key> pub = priv.public_key();

        const std::string msg = "hola";
        const std::string msg2 = "adios";
        const std::vector<uint8_t> m(msg.begin(), msg.end()); //convert to bytes
        const std::vector<uint8_t> m2(msg2.begin(), msg2.end()); 

        // 3) Sign (params="" and provider="" for default)

        //checks there are signatures available before signing
        auto remaining_initial = priv.remaining_operations(); //checks remaining operations
        if(remaining_initial.has_value()) {
            if(remaining_initial == 0){
                std::cout << "Cannot sign \n" << std::endl;
                return 0;
            }
        }

        std::unique_ptr<Botan::PK_Ops::Signature> signer =
            priv.create_signature_op(rng, /*params*/"", /*provider*/"");
        signer->update(m);
        std::vector<uint8_t> sig = signer->sign(rng);


        //std::cout << "Signature (hex): " << Botan::hex_encode(sig) << "\n";

       auto remaining = priv.remaining_operations(); //checks remaining operations
        if (remaining.has_value()) {
            std::cout << "Remaining signatures: " << remaining.value() << "\n";
            } else {
            std::cout << "Remaining signatures: (not available)\n";
        }
    
        //sign the second message
        signer->update(m2);
        std::vector<uint8_t> sig2 = signer->sign(rng);


        //std::cout << "Signature (hex): " << Botan::hex_encode(sig2) << "\n";

       auto remaining2 = priv.remaining_operations(); //checks remaining operations
        if (remaining2.has_value()) {
            std::cout << "Remaining signatures: " << remaining2.value() << "\n";
            } else {
            std::cout << "Remaining signatures: (not available)\n";
        }



        // 4) Verify
        std::unique_ptr<Botan::PK_Ops::Verification> verifier =
            pub->create_verification_op(/*params*/"", /*provider*/"");
        verifier->update(m);
        const bool ok = verifier->is_valid_signature(sig);
        std::cout << "Verification: " << (ok ? "OK" : "FAILED") << "\n";

        // 5) Save keys in binary (XMSS raw format)
        const auto priv_raw = priv.raw_private_key();
        std::ofstream("xmss_priv.bin", std::ios::binary)
            .write(reinterpret_cast<const char*>(priv_raw.data()), priv_raw.size());

        const auto pub_raw = pub->raw_public_key_bits();
        std::ofstream("xmss_pub.bin", std::ios::binary)
            .write(reinterpret_cast<const char*>(pub_raw.data()), pub_raw.size());
    } catch(const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
