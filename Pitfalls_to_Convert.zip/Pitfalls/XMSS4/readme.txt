Esta pitfall se basa en no emplear SHAKE256 como primitiva subyacente de XMSS. La versión buena utiliza esta, la mala SHA2-256. 

Pitfall_XMSS4_Good.cpp -> en la línea 16 se usa SHAKE256
Pitfall_XMSS4_nc.cpp -> en la línea 16 se usa sha2 256
