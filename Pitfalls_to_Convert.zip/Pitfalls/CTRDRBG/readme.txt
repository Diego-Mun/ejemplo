Esta pitfall se basa en utilizar un mismo ouput de CTR-DRBG para generar más de una clave. La versión buena genera una única clave, la mala 
genera dos con el mimso outuput. En ambos casos se deriva mediatne hkdf con salts distintas. Probablemente la sast no detecte esto. 

Pitfall_CTR-DRBG_c.cpp -> líneas 106-125 sólo se deriva una vez
Pitfall_CTR-DRBG_nc.cpp -> líneas 106-142 deriva dos claves con el mismo ouptut de ctr-drbg. 
