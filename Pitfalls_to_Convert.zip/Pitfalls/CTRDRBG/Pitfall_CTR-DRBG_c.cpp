#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <openssl/kdf.h>
#include <openssl/core_names.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cstring>

// Helper: print hex
static void print_hex(const std::string &label, const unsigned char *data, size_t len) {
    std::cout << label;
    for (size_t i = 0; i < len; ++i)
        std::cout << std::hex << std::setw(2) << std::setfill('0') << (int)data[i];
    std::cout << std::dec << "\n";
}

// Helper: read from /dev/random
std::vector<unsigned char> read_from_dev_random(size_t n) {
    std::vector<unsigned char> buf(n);
    std::ifstream in("/dev/random", std::ios::binary);
    if(!in) throw std::runtime_error("Failed to open /dev/random");
    in.read(reinterpret_cast<char*>(buf.data()), buf.size());
    if(in.gcount() != static_cast<std::streamsize>(buf.size()))
        throw std::runtime_error("Short read from /dev/random");
    return buf;
}

// Minimal AES-CTR-DRBG simulation using EVP
// (We manually set key+V and generate output per NIST SP 800-90A CTR_DRBG style)
std::vector<unsigned char> ctr_drbg_generate(const std::vector<unsigned char>& key,
                                             std::vector<unsigned char> V,
                                             size_t output_len)
{
    std::vector<unsigned char> out(output_len);
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if(!ctx) throw std::runtime_error("EVP_CIPHER_CTX_new failed");

    size_t produced = 0;
    while(produced < output_len) {
        // Increment V
        for(int i = (int)V.size() - 1; i >= 0; --i) {
            if(++V[i] != 0) break;
        }

        unsigned char block[16];
        int len = 0;
        if(EVP_EncryptInit_ex(ctx, EVP_aes_256_ecb(), nullptr, key.data(), nullptr) != 1)
            throw std::runtime_error("EncryptInit failed");

        EVP_CIPHER_CTX_set_padding(ctx, 0);

        if(EVP_EncryptUpdate(ctx, block, &len, V.data(), 16) != 1)
            throw std::runtime_error("EncryptUpdate failed");

        size_t to_copy = std::min((size_t)16, output_len - produced);
        std::memcpy(out.data() + produced, block, to_copy);
        produced += to_copy;
    }

    EVP_CIPHER_CTX_free(ctx);
    return out;
}

int main() {
    try {
        OpenSSL_add_all_algorithms();

        size_t seed_len = 32;
        // Get seed from /dev/random
        auto seed = read_from_dev_random(seed_len);
        print_hex("[+] Seed: ", seed.data(), seed.size());

        // 2. Derive key (32B) and V (16B), needed for the CTR-DRGB, this is not the NIST KDF, but is as close as we can get
        //without changing the openssl function
        unsigned char key[32], V[16];
        EVP_KDF *kdf = EVP_KDF_fetch(NULL, "HKDF", NULL);
        EVP_KDF_CTX *kctx = EVP_KDF_CTX_new(kdf);
        OSSL_PARAM params[] = {
            OSSL_PARAM_utf8_string(OSSL_KDF_PARAM_DIGEST, (char*)"SHA256", 0),
            OSSL_PARAM_octet_string(OSSL_KDF_PARAM_KEY, seed.data(), seed.size()),
            OSSL_PARAM_octet_string(OSSL_KDF_PARAM_INFO, (void*)"drbg-internal-derivation", 26),
            OSSL_PARAM_END
        };
        unsigned char tmp[48];
        if(EVP_KDF_derive(kctx, tmp, sizeof(tmp), params) != 1)
            throw std::runtime_error("HKDF derive failed");

        std::memcpy(key, tmp, 32);
        std::memcpy(V, tmp + 32, 16);
        EVP_KDF_CTX_free(kctx);
        EVP_KDF_free(kdf);

     
        // 3. Generate 64 bytes of random output from CTR_DRBG
        auto random_bytes = ctr_drbg_generate(
            std::vector<unsigned char>(key, key + 32),
            std::vector<unsigned char>(V, V + 16),
            64
        );

        // 4. Derive AES-256 key from DRBG output using HKDF(SHA-256)
        const unsigned char SALT1[] = {0xA5,0xA5,0xA5,0xA5,0x00,0x01};
        EVP_KDF *hkdf2 = EVP_KDF_fetch(NULL, "HKDF", NULL);
        EVP_KDF_CTX *hkctx = EVP_KDF_CTX_new(hkdf2);
        const char* info = "aes-key-derivation-demo";
        unsigned char aes_key[32];
        OSSL_PARAM params2[] = {
            OSSL_PARAM_utf8_string(OSSL_KDF_PARAM_DIGEST, (char*)"SHA256", 0),
            OSSL_PARAM_octet_string(OSSL_KDF_PARAM_KEY, random_bytes.data(), random_bytes.size()),
            OSSL_PARAM_octet_string(OSSL_KDF_PARAM_SALT,  (void*)SALT1, sizeof(SALT1)),
            OSSL_PARAM_END
        };
        if(EVP_KDF_derive(hkctx, aes_key, sizeof(aes_key), params2) != 1)
            throw std::runtime_error("HKDF derive 2 failed");

        print_hex("[+] AES-256 key: ", aes_key, sizeof(aes_key));

        EVP_KDF_CTX_free(hkctx);
        EVP_KDF_free(hkdf2);

        return 0;
    }
    catch(const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        ERR_print_errors_fp(stderr);
        return 1;
    }
}
