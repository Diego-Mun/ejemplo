Esta pitfall se basa en usar 2 claves iguales para xts. la mala usa la misma, la buena distintas. 

Pitfall_XTS_c.cpp -> en las línes 8-10 se usan claves distintas
Pitfall_XTS_nc.cpp -> en las líneas 8-10 se usa la misma clave