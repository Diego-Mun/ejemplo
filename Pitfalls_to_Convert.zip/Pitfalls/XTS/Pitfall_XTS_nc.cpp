#include <openssl/evp.h>
#include <openssl/param_build.h>
#include <openssl/core_names.h>
#include <vector>
#include <iostream>

int main() {
    std::vector<unsigned char> key1(16, 0x11);  // First subkey
    std::vector<unsigned char> key2(16, 0x11);  // Second subkey, its the same as the first subkey. 
    std::vector<unsigned char> tweak(16, 0x00); // Example tweak
    std::vector<unsigned char> plaintext(32, 0x41);
    std::vector<unsigned char> ciphertext(32);

    EVP_CIPHER *cipher = EVP_CIPHER_fetch(nullptr, "AES-128-XTS", nullptr);
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    // Build parameter list
    OSSL_PARAM params[] = {
        OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_KEY, key1.data(), key1.size()),
        OSSL_PARAM_construct_octet_string(OSSL_CIPHER_PARAM_XTS_KEY2, key2.data(), key2.size()),
        OSSL_PARAM_construct_end()
    };

    EVP_EncryptInit_ex2(ctx, cipher, nullptr, tweak.data(), params);

    int outl;
    EVP_EncryptUpdate(ctx, ciphertext.data(), &outl, plaintext.data(), plaintext.size());
    EVP_EncryptFinal_ex(ctx, ciphertext.data()+outl, &outl);

    std::cout << "Encrypted first 16 bytes: ";
    for (int i = 0; i < 16; ++i) printf("%02x", ciphertext[i]);
    std::cout << "\n";

    EVP_CIPHER_CTX_free(ctx);
    EVP_CIPHER_free(cipher);
}
