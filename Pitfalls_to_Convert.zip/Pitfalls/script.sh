#!/bin/bash

# Navega recursivamente por el directorio actual
# y renombra archivos que contengan "Good" o "Bad" en su nombre

find . -depth -type f | while read -r file; do
    dir=$(dirname "$file")
    base=$(basename "$file")

    # Nuevo nombre con los reemplazos deseados
    newbase=${base//Good/c}
    newbase=${newbase//Bad/nc}

    # Solo renombrar si hay cambios
    if [[ "$base" != "$newbase" ]]; then
        newpath="$dir/$newbase"
        echo "Renombrando: $file → $newpath"
        mv "$file" "$newpath"
    fi
done
