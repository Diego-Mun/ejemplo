#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/rand.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>

static void die(const char *msg) {
    std::cerr << msg << "\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

static std::vector<unsigned char> read_file(const std::string &path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) die(("Cannot open file: " + path).c_str());
    return std::vector<unsigned char>((std::istreambuf_iterator<char>(f)),
                                      std::istreambuf_iterator<char>());
}

static void print_hex(const std::string &label, const unsigned char *buf, size_t len) {
    std::cout << label;
    for (size_t i = 0; i < len; ++i)
        std::cout << std::hex << std::setw(2) << std::setfill('0') << (int)buf[i];
    std::cout << std::dec << "\n";
}

int main() {
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    // Loads a key from file, used for signing
    BIO *bio_sign = BIO_new_file("signing_key.pem", "r");
    if (!bio_sign) die("Missing signing_key.pem");
    EVP_PKEY *sign_key = PEM_read_bio_PrivateKey(bio_sign, nullptr, nullptr, nullptr);
    BIO_free(bio_sign);
    if (!sign_key) die("Failed to load signing_key.pem");

    // Loads AES-KEY from file
    std::vector<unsigned char> aes_key = read_file("aes_key.pem");
    if (aes_key.size() < 32)
        die("aes_key.pem must contain at least 32 bytes (AES-256 key)");

    // Generates keys to be output
    EVP_PKEY_CTX *pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_EC, NULL);
    if (!pctx) die("EVP_PKEY_CTX_new_id failed");
    if (EVP_PKEY_keygen_init(pctx) <= 0) die("EVP_PKEY_keygen_init failed");
    if (EVP_PKEY_CTX_set_ec_paramgen_curve_nid(pctx, NID_secp384r1) <= 0)
        die("Set curve failed");

    EVP_PKEY *new_key = nullptr;
    if (EVP_PKEY_keygen(pctx, &new_key) <= 0) die("EVP_PKEY_keygen failed");
    EVP_PKEY_CTX_free(pctx);
    std::cout << "Generated ECDSA P-384 keypair\n";

    // ---- 4) Extract public key DER ----
    unsigned char *pub_der = nullptr;
    int pub_der_len = i2d_PUBKEY(new_key, &pub_der);
    if (pub_der_len <= 0) die("i2d_PUBKEY failed");

    // ---- 5) Sign the public key DER ----
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    if (!mdctx) die("EVP_MD_CTX_new failed");
    if (EVP_DigestSignInit(mdctx, nullptr, EVP_sha384(), nullptr, sign_key) != 1)
        die("DigestSignInit failed");

    size_t sig_len = 0;
    if (EVP_DigestSign(mdctx, nullptr, &sig_len, pub_der, pub_der_len) != 1)
        die("DigestSign (size) failed");

    std::vector<unsigned char> signature(sig_len);
    if (EVP_DigestSign(mdctx, signature.data(), &sig_len, pub_der, pub_der_len) != 1)
        die("DigestSign failed");

    signature.resize(sig_len);
    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_free(sign_key);

    // ---- 6) Encrypt private key with AES-256-GCM using the AES key ----
    // Generate random IV (12 bytes)
    unsigned char iv[12];
    if (RAND_bytes(iv, sizeof(iv)) != 1) die("RAND_bytes failed");

    unsigned char tag[16];

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) die("EVP_CIPHER_CTX_new failed");

    const EVP_CIPHER *cipher = EVP_aes_256_gcm();

    if (EVP_EncryptInit_ex(ctx, cipher, nullptr, nullptr, nullptr) != 1)
        die("EncryptInit_ex failed");
    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, sizeof(iv), nullptr) != 1)
        die("set ivlen failed");
    if (EVP_EncryptInit_ex(ctx, nullptr, nullptr, aes_key.data(), iv) != 1)
        die("EncryptInit key/iv failed");

    // Get private key DER
    unsigned char *priv_der = nullptr;
    int priv_der_len = i2d_PrivateKey(new_key, &priv_der);
    if (priv_der_len <= 0) die("i2d_PrivateKey failed");

    std::vector<unsigned char> ciphertext(priv_der_len + 16);
    int out_len = 0, total = 0;
    if (EVP_EncryptUpdate(ctx, ciphertext.data(), &out_len, priv_der, priv_der_len) != 1)
        die("EncryptUpdate failed");
    total = out_len;
    if (EVP_EncryptFinal_ex(ctx, ciphertext.data() + total, &out_len) != 1)
        die("EncryptFinal_ex failed");
    total += out_len;

    if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, sizeof(tag), tag) != 1)
        die("get tag failed");

    EVP_CIPHER_CTX_free(ctx);
    ciphertext.resize(total);

    // ---- 7) Write outputs ----
    BIO *bio_pub = BIO_new_file("ecdsa_p384_pub.pem", "w");
    if (!bio_pub) die("BIO_new_file pub failed");
    if (PEM_write_bio_PUBKEY(bio_pub, new_key) != 1) die("write pub failed");
    BIO_free(bio_pub);

    std::ofstream sigfile("ecdsa_p384_pub.sig", std::ios::binary);
    sigfile.write((const char*)signature.data(), signature.size());
    sigfile.close();

    std::ofstream encpriv("ecdsa_p384_priv_enc.pem", std::ios::binary);
    encpriv.write((const char*)iv, sizeof(iv));      // prepend IV
    encpriv.write((const char*)ciphertext.data(), ciphertext.size());
    encpriv.write((const char*)tag, sizeof(tag));    // append tag
    encpriv.close();

    std::cout << "Saved encrypted private key -> ecdsa_p384_priv_enc.pem\n";
    std::cout << "Saved public key -> ecdsa_p384_pub.pem\n";
    std::cout << "Saved signature -> ecdsa_p384_pub.sig\n";

    // Cleanup
    EVP_PKEY_free(new_key);
    OPENSSL_free(pub_der);
    OPENSSL_free(priv_der);
    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
