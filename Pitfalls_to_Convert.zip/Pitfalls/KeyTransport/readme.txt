Esta pitfall se basa en generar y exportar claves sin asegurar su autenticidad e integridad para públicas y sin comprobar autenticidad, integridad ni 
confidencialidad para claves privadas. 

Pitfall_KeyTransport_c.cpp -> líneas 59-135 firma la clave pública y cifra la privada. 
Pitfall_KeyTransport_nc.cpp -> líneas 35-52 exporta las claves sin asegurar nada. 
