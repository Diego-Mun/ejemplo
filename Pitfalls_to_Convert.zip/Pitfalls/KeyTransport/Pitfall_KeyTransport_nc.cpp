// gen_ecdsa_p384.cpp
// Generate ECDSA P-384 keypair and save to PEM files (OpenSSL 3+).
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/pem.h>

#include <iostream>

static void die(const char *msg) {
    std::cerr << msg << "\n";
    ERR_print_errors_fp(stderr);
    std::exit(EXIT_FAILURE);
}

int main() {
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    EVP_PKEY *pkey = nullptr;
    EVP_PKEY_CTX *pctx = nullptr;

    // 1) Create keygen context for EC keys
    pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_EC, NULL);
    if (!pctx) die("EVP_PKEY_CTX_new_id failed");

    if (EVP_PKEY_keygen_init(pctx) <= 0) die("EVP_PKEY_keygen_init failed");

    // Set curve to secp384r1 (P-384)
    if (EVP_PKEY_CTX_set_ec_paramgen_curve_nid(pctx, NID_secp384r1) <= 0)
        die("EVP_PKEY_CTX_set_ec_paramgen_curve_nid failed");

    // 2) Generate keypair
    if (EVP_PKEY_keygen(pctx, &pkey) <= 0) die("EVP_PKEY_keygen failed");

    // 3) Write private key to PEM file (unencrypted)
    {
        BIO *bio_priv = BIO_new_file("ecdsa_p384_priv.pem", "w");
        if (!bio_priv) die("BIO_new_file for private key failed");
        if (PEM_write_bio_PrivateKey(bio_priv, pkey, NULL, NULL, 0, NULL, NULL) != 1)
            die("PEM_write_bio_PrivateKey failed");
        BIO_free(bio_priv);
        std::cout << "Wrote private key -> ecdsa_p384_priv.pem\n";
    }

    // 4) Write public key to PEM file (SubjectPublicKeyInfo)
    {
        BIO *bio_pub = BIO_new_file("ecdsa_p384_pub.pem", "w");
        if (!bio_pub) die("BIO_new_file for public key failed");
        if (PEM_write_bio_PUBKEY(bio_pub, pkey) != 1) die("PEM_write_bio_PUBKEY failed");
        BIO_free(bio_pub);
        std::cout << "Wrote public key  -> ecdsa_p384_pub.pem\n";
    }

    // Cleanup
    EVP_PKEY_free(pkey);
    EVP_PKEY_CTX_free(pctx);

    EVP_cleanup();          
    ERR_free_strings();

    return 0;
}
