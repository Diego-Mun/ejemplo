#include <openssl/evp.h>
#include <openssl/err.h>

#include <iostream>
#include <iomanip>
#include <vector>
#include <cstring>

static void print_hex(const std::string& label, const unsigned char* data, size_t len)
{
    std::cout << label;
    for (size_t i = 0; i < len; ++i)
        std::cout << std::hex << std::setw(2) << std::setfill('0') << (int)data[i];
    std::cout << std::dec << "\n";
}

static void handle_errors(const std::string& msg)
{
    std::cerr << msg << "\n";
    ERR_print_errors_fp(stderr);
    exit(EXIT_FAILURE);
}

/* AES-256-GCM encryption */
std::vector<unsigned char> aes256_gcm_encrypt(const std::vector<unsigned char>& key,
                                              const std::vector<unsigned char>& iv,
                                              const std::vector<unsigned char>& plaintext,
                                              std::vector<unsigned char>& tag)
{
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if(!ctx) handle_errors("EVP_CIPHER_CTX_new failed");

    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr))
        handle_errors("EVP_EncryptInit_ex failed");

    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, (int)iv.size(), nullptr))
        handle_errors("EVP_CTRL_GCM_SET_IVLEN failed");

    if(1 != EVP_EncryptInit_ex(ctx, nullptr, nullptr, key.data(), iv.data()))
        handle_errors("EVP_EncryptInit_ex (key/iv) failed");

    std::vector<unsigned char> ciphertext(plaintext.size());
    int out_len = 0, total_len = 0;

    if(1 != EVP_EncryptUpdate(ctx, ciphertext.data(), &out_len, plaintext.data(), plaintext.size()))
        handle_errors("EVP_EncryptUpdate failed");
    total_len = out_len;

    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext.data() + total_len, &out_len))
        handle_errors("EVP_EncryptFinal_ex failed");
    total_len += out_len;
    ciphertext.resize(total_len);

    tag.resize(16);
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, tag.size(), tag.data()))
        handle_errors("EVP_CTRL_GCM_GET_TAG failed");

    EVP_CIPHER_CTX_free(ctx);
    return ciphertext;
}

/* AES-256-CBC encryption (PKCS#7 padding) */
std::vector<unsigned char> aes256_cbc_encrypt(const std::vector<unsigned char>& key,
                                              const std::vector<unsigned char>& iv,
                                              const std::vector<unsigned char>& plaintext)
{
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if(!ctx) handle_errors("EVP_CIPHER_CTX_new failed");

    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), nullptr, key.data(), iv.data()))
        handle_errors("EVP_EncryptInit_ex failed");

    std::vector<unsigned char> ciphertext(plaintext.size() + EVP_CIPHER_block_size(EVP_aes_256_cbc()));
    int out_len = 0, total_len = 0;

    if(1 != EVP_EncryptUpdate(ctx, ciphertext.data(), &out_len, plaintext.data(), plaintext.size()))
        handle_errors("EVP_EncryptUpdate failed");
    total_len = out_len;

    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext.data() + total_len, &out_len))
        handle_errors("EVP_EncryptFinal_ex failed");
    total_len += out_len;
    ciphertext.resize(total_len);

    EVP_CIPHER_CTX_free(ctx);
    return ciphertext;
}

int main()
{
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();

    const std::string plaintext_str =
        "The quick brown fox jumps over the lazy dog.";

    const std::vector<unsigned char> plaintext(plaintext_str.begin(), plaintext_str.end());

    /*
    A different key for each encryption method. It avoids Pitfall keyUsage, but fails CWE-321 hardcoded keys
    */
    const std::vector<unsigned char> key = {
        0x60,0x61,0x62,0x63,0x64,0x65,0x66,0x67,
        0x68,0x69,0x6a,0x6b,0x6c,0x6d,0x6e,0x6f,
        0x70,0x71,0x72,0x73,0x74,0x75,0x76,0x77,
        0x78,0x79,0x7a,0x7b,0x7c,0x7d,0x7e,0x7f
    };

    const std::vector<unsigned char> iv_gcm = { 0x01,0x03,0x03,0x07,0x0F,0x1F,0x3F,0x7F,0x11,0x22,0x33,0x44 };
    const std::vector<unsigned char> iv_cbc = { 0xa0,0xa1,0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,
                                                0xa8,0xa9,0xaa,0xab,0xac,0xad,0xae,0xaf };

    // AES-GCM
    std::vector<unsigned char> gcm_tag;
    auto gcm_ct = aes256_gcm_encrypt(key, iv_gcm, plaintext, gcm_tag);

    print_hex("GCM CT : ", gcm_ct.data(), gcm_ct.size());
    // AES-CBC
    auto cbc_ct = aes256_cbc_encrypt(key, iv_cbc, plaintext);

    print_hex("CBC CT : ", cbc_ct.data(), cbc_ct.size());

    EVP_cleanup();
    ERR_free_strings();
    return 0;
}
