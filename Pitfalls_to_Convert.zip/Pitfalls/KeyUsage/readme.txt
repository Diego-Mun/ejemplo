Esta pitfall se basa en emplear la misma clave para dos mecanismos distintos. En este caso tenemos aes-cbc y aes-gcm. La buena usa claves distintas, la mala la misma. 
Ambas inclumplen CWE-321 al tener claves hardcodeadas. 

Pitfall_KeyUsage_c.cpp -> líneas 102-125 se definen y usan claves distintas para cada mecanismo
Pitfall_KeyUsage_nc.cpp -> líneas 109-119 se usa la misma clave para dos mecanismos distintos. 
