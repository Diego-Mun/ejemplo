#include <openssl/evp.h>
#include <openssl/core_names.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/provider.h>

#include <algorithm>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

// ------------------------------------------------------
// Utilities
// ------------------------------------------------------
static void print_openssl_errors(const char* where) {
    unsigned long err = 0;
    std::cerr << "[OpenSSL error] in " << where << ":\n";
    while ((err = ERR_get_error()) != 0)
        std::cerr << "  - " << ERR_error_string(err, nullptr) << "\n";
}

static void ensure(bool ok, const char* where) {
    if (!ok) {
        print_openssl_errors(where);
        throw std::runtime_error(std::string("OpenSSL failure at: ") + where);
    }
}

static std::vector<unsigned char> hex_to_bytes(std::string hex) {
    hex.erase(std::remove_if(hex.begin(), hex.end(), ::isspace), hex.end());
    if (hex.size() % 2 != 0) throw std::invalid_argument("Odd-length hex");
    std::vector<unsigned char> out(hex.size() / 2);
    for (size_t i = 0; i < out.size(); ++i) {
        unsigned int byte = 0;
        std::sscanf(hex.substr(2 * i, 2).c_str(), "%02x", &byte);
        out[i] = static_cast<unsigned char>(byte);
    }
    return out;
}

static std::string to_hex(const unsigned char* p, size_t n) {
    std::ostringstream oss;
    for (size_t i = 0; i < n; ++i)
        oss << std::hex << std::setfill('0') << std::setw(2) << (unsigned int)p[i];
    return oss.str();
}
static std::string to_hex(const std::vector<unsigned char>& v) { return to_hex(v.data(), v.size()); }

// ------------------------------------------------------
// IV generation
// ------------------------------------------------------
static std::vector<unsigned char> gen_iv_cfb() {
    std::vector<unsigned char> iv(16);
    ensure(RAND_bytes(iv.data(), (int)iv.size()) == 1, "RAND_bytes CFB");
    return iv;
}

static std::vector<unsigned char> gen_iv_ofb() {
    std::vector<unsigned char> iv(16);
    ensure(RAND_bytes(iv.data(), (int)iv.size()) == 1, "RAND_bytes OFB");
    return iv;
}

// CTR: nonce (12 B) + counter (4 B = 0x00000001)
static std::vector<unsigned char> gen_iv_ctr() {
    std::vector<unsigned char> iv(16, 0x00);
    ensure(RAND_bytes(iv.data(), 12) == 1, "RAND_bytes nonce");
    iv[12] = 0x00;
    iv[13] = 0x00;
    iv[14] = 0x00;
    iv[15] = 0x01;
    return iv;
}

// ------------------------------------------------------
// Generic encryption for stream modes (no padding)
// ------------------------------------------------------
static std::vector<unsigned char> aes_stream_encrypt(
    const EVP_CIPHER* cipher,
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& iv,
    const std::vector<unsigned char>& pt)
{
    EVP_CIPHER_CTX* raw = EVP_CIPHER_CTX_new();
    ensure(raw != nullptr, "EVP_CIPHER_CTX_new");
    std::unique_ptr<EVP_CIPHER_CTX, decltype(&EVP_CIPHER_CTX_free)> ctx(raw, EVP_CIPHER_CTX_free);

    ensure(EVP_EncryptInit_ex2(ctx.get(), cipher, key.data(), iv.data(), nullptr) == 1,
           "EVP_EncryptInit_ex2");
    ensure(EVP_CIPHER_CTX_set_padding(ctx.get(), 0) == 1, "disable padding");

    std::vector<unsigned char> ct(pt.size() + 16);
    int outl = 0, tot = 0;
    ensure(EVP_EncryptUpdate(ctx.get(), ct.data(), &outl, pt.data(), (int)pt.size()) == 1,
           "EncryptUpdate");
    tot += outl;
    ensure(EVP_EncryptFinal_ex(ctx.get(), ct.data() + tot, &outl) == 1, "EncryptFinal_ex");
    tot += outl;
    ct.resize(tot);
    return ct;
}

// ------------------------------------------------------
// Encryption wrappers by mode
// ------------------------------------------------------
static std::vector<unsigned char> encrypt_aes128_cfb(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& iv,
    const std::vector<unsigned char>& pt) {
    return aes_stream_encrypt(EVP_aes_128_cfb128(), key, iv, pt);
}

static std::vector<unsigned char> encrypt_aes128_ofb(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& iv,
    const std::vector<unsigned char>& pt) {
    return aes_stream_encrypt(EVP_aes_128_ofb(), key, iv, pt);
}

static std::vector<unsigned char> encrypt_aes128_ctr(
    const std::vector<unsigned char>& key,
    const std::vector<unsigned char>& iv,
    const std::vector<unsigned char>& pt) {
    return aes_stream_encrypt(EVP_aes_128_ctr(), key, iv, pt);
}

// ------------------------------------------------------
// main
// ------------------------------------------------------
int main(int argc, char* argv[]) {
    try {
        if (argc != 3) {
            std::cerr << "Usage: " << argv[0] << " <mode: cfb|ofb|ctr> <key_hex_128bit>\n";
            return 1;
        }

        std::string mode = argv[1];
        std::transform(mode.begin(), mode.end(), mode.begin(),
                       [](unsigned char c) { return std::tolower(c); });

        std::vector<unsigned char> key = hex_to_bytes(argv[2]);
        if (key.size() != 16) {
            std::cerr << "Key must be 16 bytes (AES-128)\n";
            return 1;
        }

        OSSL_PROVIDER* defprov = OSSL_PROVIDER_load(nullptr, "default");
        ensure(defprov != nullptr, "OSSL_PROVIDER_load(default)");

        const std::string plaintext_str = "hi this is encrypted";
        std::vector<unsigned char> pt(plaintext_str.begin(), plaintext_str.end());
        std::vector<unsigned char> iv, ct;

        if (mode == "cfb") {
            iv = gen_iv_cfb();
            ct = encrypt_aes128_cfb(key, iv, pt);
        } else if (mode == "ofb") {
            iv = gen_iv_ofb();
            ct = encrypt_aes128_ofb(key, iv, pt);
        } else if (mode == "ctr") {
            iv = gen_iv_ctr();
            ct = encrypt_aes128_ctr(key, iv, pt);
        } else {
            std::cerr << "Invalid mode. Use cfb | ofb | ctr\n";
            OSSL_PROVIDER_unload(defprov);
            return 1;
        }

        std::cout << "Mode: " << mode << "\n";
        std::cout << "Key: " << to_hex(key) << "\n";
        std::cout << "IV : " << to_hex(iv) << "\n";
        std::cout << "CT : " << to_hex(ct) << "\n";

        OSSL_PROVIDER_unload(defprov);
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "Exception: " << ex.what() << "\n";
        return 2;
    }
}
