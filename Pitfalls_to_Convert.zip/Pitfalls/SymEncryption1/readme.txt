Esta pitfall se basa en emplear el IV de mecanismos de cifrado simétrico mal. Para CBC y CFB debe ser aleatorio. OFB no debe reutilizar IV. CTR debe 
comenzar con un IV aleatorio y concatenar un buffer iniciado a 0. CBC ya está cubierta por CWE-329.
La versión buena implementa todo bien, la mala utiliza IV fijo para CFB, reutiliza IV para OFB y utiliza un IV estático para CTR. 


Pitfall_SymEncryption1_c.cpp ->57 -79 genera bien los IVs
Pitfall_SymEncryption1_nc.cpp -> 55-88 genera mal IV, 120-152 ctr sin aumentar counter. 